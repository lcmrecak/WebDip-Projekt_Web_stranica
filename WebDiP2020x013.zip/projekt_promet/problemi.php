<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$putanja = dirname($_SERVER["REQUEST_URI"]);
$direktorij = dirname(getcwd());
include 'zaglavlje.php';
include './dnevnik_rada.php';
$dnevnik = new Dnevnik();


if (!isset($_SESSION["uloga"])) {
    header("Location: index.php");
    exit();
} elseif (isset($_SESSION["uloga"]) && $_SESSION["uloga"] > 2) {
    header("Location: index.php");
} else {
    if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] <= 2) {
        $veza = new Baza();
        $veza->spojiDB();

        $upit = "SELECT cesta.oznaka, cesta.status, problem.naziv_problema, problem.opis, problem.datum_vrijeme FROM cesta, problem "
                . "WHERE problem.cesta_id=cesta.cesta_id";
        $rezultat = $veza->selectDB($upit);
        $dataRow = "";
        while ($red = mysqli_fetch_array($rezultat)) {
            $dataRow = $dataRow . "<tr><td><a href=\"$putanja/problemi.php?oznaka={$red['oznaka']}&status={$red['status']}\">$red[0]</td><td>$red[1]</td><td>$red[2]</td><td>$red[3]</td><td>$red[4]</td></tr>";
        }


        if (isset($_POST['submit'])) {
            $oznaka = $_REQUEST['oznaka'];
            $upitID = "SELECT cesta.cesta_id FROM cesta WHERE cesta.oznaka = \"$oznaka\"";
            $rezultat2 = $veza->selectDB($upitID);

            $cesta_id = "";
            while ($red = mysqli_fetch_array($rezultat2)) {
                $cesta_id = $red[0];
            }


            $status = $_REQUEST['status'];

            $upitUpdate = "UPDATE `cesta` SET `status` = '{$status}' "
                    . "WHERE `cesta`.`cesta_id` = {$cesta_id}";

            $rezultat3 = $veza->selectDB($upitUpdate);

            $dnevnikUpit = $upitUpdate;
            $radnja = "Ažuriran status ceste";
            $tip_radnje = "2";
            $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);

            header("Location: problemi.php");
        }
    }
}
?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">
    <head>
        <title>Pregled problema</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="naslov" content="Promet">        
        <meta name="autor" content="Lovro Cmrecak">
        <meta name="keywords" content="promet, projekt, webdip, evidencija, prijava, problem">
        <meta name="opis" content="Stranica s obrascem za evidenciju i prijavu problema projekta Promet. Kreirano 2.6.2021.">
        <link href='css/lcmrecak.css' type="text/css" rel="stylesheet"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script>
            $(document).ready(function () {
                $("#myInput").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
        </script>

    </head>
    <body>

        <header>
            <img src="multimedija/instagram-logo.png" alt="instagram" width="30"/>
            <img src="multimedija/facebook-logo.png" alt="facebook" width="30"/>
            <a href="rss.php"><img src="multimedija/rss-logo.png" alt="rss" width="30"/></a>
            <a href="#sadrzaj"><h1>Pregled problema</h1></a>

        </header>
        <nav id="navigacija">
            <?php
            include 'meni.php';
            ?>
        </nav>
        <section id="sadrzaj">
            <h2 style="text-align: center;padding-top: 4%; font-weight: bold;">Popis otvorenih dionica</h2>
            <form style="margin-top: 0%">
                <input id="myInput" type="text" placeholder="Pretražite tablicu">
            </form>

            <table style="margin-top: 1%">

                <thead>
                    <tr>
                        <th>Oznaka dionice</th>
                        <th>Status dionice</th>
                        <th>Naziv problema</th>
                        <th>Opis problema</th>
                        <th>Datum prijave</th>

                    </tr>

                </thead>
                <tbody id="tablicaBody">
                    <?php
                    echo $dataRow;
                    ?>

                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="5">PROMET</td>
                    </tr>
                </tfoot>

            </table>


            <form action="" method="post" id="form1" name="form1" style="margin-top: 1%">

                <?php
                if (isset($_GET['oznaka'])) {
                    $status = $_GET['status'];
                    echo "<label for=\"oznaka\"><b>Oznaka</b></label>";
                    echo "<input readonly type=\"text\" value=\"{$_GET['oznaka']}\" name=\"oznaka\" id=\"oznaka\">
                    <label for=\"status\"><b>Status</b></label>
                    <select id=\"status\" name=\"status\" placeholder=\"Status..\">
                    <option  selected=\"selected\">$status</option>
                    <option  disabled>-------------------------------</option>
                    <option  value=\"O\">O</option>
                    <option  value=\"Z\">Z</option>
                    </select> 
                    <input name=\"submit\" id=\"submit\" type=\"submit\" value=\"Ažuriraj status dionice\">";
                } else {
                    echo "<h2 style=\"text-align:center\"><b>Kliknite na oznaku ceste za promjenu statusa</b></h2>";
                }
                ?>

            </form>


        </section>
        <br>
        <br>
        <br>
        <br>
    <div class="footer">
        <p>&copy;2020 Lovro Cmrečak</a></p>
    </div>


    </body>
</html>