<?php

require "baza.class.php";
require "sesija.class.php";
Sesija::kreirajSesiju();

?>