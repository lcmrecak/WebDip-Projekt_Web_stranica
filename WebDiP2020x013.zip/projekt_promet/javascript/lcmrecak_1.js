
window.addEventListener("load", function () {

  
    document.getElementById("slika").addEventListener("click", function () {
        var elementi = document.getElementsByTagName('link')[0];
        if (elementi.getAttribute('href') === 'css/lcmrecak.css') {
            elementi.setAttribute('href', 'css/lcmrecak_accesibility.css');
        } else {
            elementi.setAttribute('href', 'css/lcmrecak.css');
        }
    });   
  
});