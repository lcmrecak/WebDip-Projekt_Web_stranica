
window.addEventListener("load", function () {
    document.getElementById("myPopup").addEventListener("click", function () {
        var popup = document.getElementById("myPopup");
        popup.classList.toggle("hide");

        var popup2 = document.getElementById("myPopup2");
        popup2.classList.toggle("show");

    });
    document.getElementById("myPopup2").addEventListener("click", function () {
        var popup = document.getElementById("myPopup2");
        popup.classList.toggle("show");

        var popup2 = document.getElementById("myPopup3");
        popup2.classList.toggle("show");

    });


    document.getElementById("accesibility").addEventListener("click", function () {
        var slika = document.getElementsByTagName('link')[0];
        if (slika.getAttribute('href') === '../css/lcmrecak.css') {
            slika.setAttribute('href', '../css/lcmrecak_accesibility.css');
        } else {
            slika.setAttribute('href', '../css/lcmrecak.css');
        }
    });

});

    