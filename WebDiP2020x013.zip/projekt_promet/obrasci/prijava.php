<?php
$putanja = dirname($_SERVER['REQUEST_URI']);
$direktorij = dirname(getcwd());

if(!isset($_SERVER["HTTPS"]) || $_SERVER["HTTPS"] != "on"){
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"], true, 301);
    exit;
    }

include "../zaglavlje.php";
include '../dnevnik_rada.php';
$dnevnik = new Dnevnik();

if (isset($_GET['submit'])) {
    
    $greska = "";
    $poruka = "";
    foreach ($_GET as $k => $v) {
        if (empty($v)) {
            $greska .= "Nije popunjeno: " . $k . "<br>";
        }
    }
    if (empty($greska)) {
        
        $veza = new Baza();
        $veza->spojiDB();

        $korime = $_GET['korime'];
        $lozinka = $_GET['lozinka'];
        setCookie('posljednjiUser');

       
        $upit = "SELECT * FROM `korisnik` WHERE "
                . "`korisnicko_ime`='{$korime}' AND "
                . "`lozinka`='{$lozinka}'";

        
        $rezultat = $veza->selectDB($upit);
        
        $autenticiran = false;
        while ($red = mysqli_fetch_array($rezultat)) {
           
            if ($red && $red['status']=="Aktivan") {
                $autenticiran = true;
                $uloga = $red["uloga_korisnika_uloga_korisnika_id"];
                $email = $red["email"];
            }
        }

        if ($autenticiran) {
            $poruka = 'Uspješna prijava!';

            Sesija::kreirajKorisnika($korime, $uloga);
            $dnevnikUpit="";
$radnja="Uspješna prijava";
$tip_radnje="1";
$upisDnevnik=$dnevnik->unosDnevnik($dnevnikUpit,$radnja, $tip_radnje);
            header("Location: ../index.php");
        } else {
            $poruka = 'Neuspješna prijava!';
        }

        $veza->zatvoriDB();
    }
} 
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">
    <head>
        <title>Prijava</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="naslov" content="Promet">        
        <meta name="autor" content="Lovro Cmrecak">
        <meta name="keywords" content="promet, projekt, webdip, prijava">
        <meta name="opis" content="Stranica za prijavu projekta Promet. Kreirano 2.6.2021.">
        <link href='../css/lcmrecak.css' type="text/css" rel="stylesheet"/>
                <script src="../javascript/lcmrecak.js"></script>
        
        <style>
            .popup {
                position: relative;
                display: inline-block;
                cursor: pointer;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
                width: 20%;
            }
            .popup .popuptext1 {
                visibility: visible;
                width: 100%;
                background-color: grey;
                color: white;
                text-align: center;
                padding: 8px 0;
                position: absolute;
                z-index: 1;
                left: -110%;
                font-size:small;

            }

            .popup .popuptext {
                visibility: hidden;
                width: 100%;
                background-color: grey;
                color: white;
                text-align: center;
                padding: 8px 0;
                position: absolute;
                z-index: 1;
                bottom: 0%;
                left: -110%;
                font-size:small;

            }

            .popup .show {
                visibility: visible;
            }
            .popup .hide{
                visibility: hidden;
            }
            img:hover{
                cursor:pointer;
            }

        </style>

    </head>
    <body>
        <header>
            <img src="../multimedija/instagram-logo.png" alt="instagram" width="30"/>
            <img src="../multimedija/facebook-logo.png" alt="facebook" width="30"/>
            <a href="../rss.php"><img src="../multimedija/rss-logo.png" alt="rss" width="30"/></a>
            <a href="#sadrzaj"><h1>MARVEL CINEMATIC UNIVERSE </h1></a>

        </header>
        <nav id="navigacija">
<?php
include '../meni.php';
?>
        </nav>
        <section id="sadrzaj">

            <form action="" name="form" method="get">

                <div class="container">
                    <h2 style="text-align: center;padding-bottom: 2%">Prijavite se</h2>
                    <div class="popup"><br>
                        <span class="popuptext1" id="myPopup">Primjer korisničkog imena: korisnik1909<br><i>Klikni me da me ugasiš</i></span>
                    <label for="korime"><b>Korisničko ime</b></label>
                    </div>
                    
                    <input type="text" placeholder="Vaše korisničko ime..." name="korime" id="korime" >
                    
                    <div class="popup"><br>
                        <span class="popuptext" id="myPopup2">Primjer lozinke: Lozinka1<br><i>Klikni me da me ugasiš</i></span>

                        <label for="lozinka"><b>Lozinka</b></label>
                    </div>

                    
                    <input type="password" placeholder="Vaša lozinka" name="lozinka" id="lozinka" >

                    <input name="submit" id="submit" type="submit" value="Prijavi se">

                </div>
            </form>

            <div>
<?php
if (isset($greska)) {
    echo "<p>$greska</p>";
}
if (isset($poruka)) {
    echo "<p>$poruka</p>";
}
?>
            </div>

        </section>
        <br>
        <br>
        <br>
        <br>
    <div class="footer">
        <p>&copy;2020 Lovro Cmrečak</a></p>
    </div>


    </body>
</html>