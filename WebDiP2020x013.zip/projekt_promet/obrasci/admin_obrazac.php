<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$putanja = dirname($_SERVER["REQUEST_URI"]);
$direktorij = dirname(getcwd());
include '../zaglavlje.php';
include '../dnevnik_rada.php';
$dnevnik = new Dnevnik();

if (!isset($_SESSION["uloga"])) {
    header("Location: ../index.php");
    exit();
} elseif (isset($_SESSION["uloga"]) && $_SESSION["uloga"] > 1) {
    header("Location: ../index.php");
} else {
    if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] == 1) {
        $veza = new Baza();
        $veza->spojiDB();
        $dnevnik = new Dnevnik();

        $korisnik = $_SESSION["korisnik"];
        $upit3 = "SELECT korisnik.korisnik_id FROM korisnik WHERE korisnik.korisnicko_ime = '{$korisnik}'";

        $rezultat3 = $veza->selectDB($upit3);

        $ID_korisnika = 0;
        while ($red1 = mysqli_fetch_array($rezultat3)) {
            $ID_korisnika = $red1[0];
        }

        $upit = "SELECT kategorija_ceste_id, naziv_kategorije, opis_kategorije FROM kategorija_ceste";
        $rezultat = $veza->selectDB($upit);
        $dataRow = "";
        while ($red = mysqli_fetch_array($rezultat)) {
            $dataRow = $dataRow . "<tr><td><a href=\"$putanja/admin_obrazac.php?kategorija_id={$red['kategorija_ceste_id']}"
                    . "&kategorija={$red['naziv_kategorije']}"
                    . "&opis={$red['opis_kategorije']}\">$red[0]</a></td><td><a href=\"$putanja/admin_obrazac.php?kategorija_id={$red['kategorija_ceste_id']}"
                    . "&kategorija={$red['naziv_kategorije']}"
                    . "&opis={$red['opis_kategorije']}\">$red[1]</td><td>$red[2]</td></tr>";
        }

        if (isset($_POST['submit2'])) {
            $greska = "";

            foreach ($_POST as $k => $v) {
                if (empty($v)) {
                    $greska .= "Nije popunjeno: $k <br>";
                }
            }
            if (empty($greska)) {
                $naziv = $_REQUEST['naziv'];
                $opis = $_REQUEST['opis'];

                $upitInsert = "INSERT INTO `kategorija_ceste` (`kategorija_ceste_id`, `naziv_kategorije`, `opis_kategorije`) "
                        . "VALUES (NULL, '{$naziv}', '{$opis}');";

                $rezultat2 = $veza->selectDB($upitInsert);

                $dnevnikUpit = $upitInsert;
                $radnja = "Kreirana nova kategorija ceste";
                $tip_radnje = "2";
                $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);

                header("Location: admin_obrazac.php");
            }
        }
        if (isset($_POST['submit6'])) {
            $kategorija_id = $_REQUEST['kategorija_id'];
            $naziv = $_REQUEST['naziv'];
            $opis = $_REQUEST['opis'];
            $greska2 = "";

            foreach ($_POST as $k => $v) {
                if (empty($v)) {
                    $greska2 .= "Nije popunjeno: $k <br>";
                }
            }
            if (empty($greska2)) {

                $upitUpdate = "UPDATE `kategorija_ceste` SET `naziv_kategorije` = '{$naziv}', `opis_kategorije` = '{$opis}' "
                        . "WHERE `kategorija_ceste`.`kategorija_ceste_id` = $kategorija_id;";

                $rezultat4 = $veza->selectDB($upitUpdate);

                $dnevnikUpit = $upitUpdate;
                $radnja = "Ažurirana kategorija ceste";
                $tip_radnje = "2";
                $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);

                header("Location: admin_obrazac.php");
            }
        }
        if (isset($_POST['submit3'])) {
            $kategorija_id = $_REQUEST['kategorija_id'];

            $upitDelete = "DELETE FROM `kategorija_ceste` WHERE `kategorija_ceste`.`kategorija_ceste_id` = $kategorija_id";

            $rezultat5 = $veza->selectDB($upitDelete);

            $dnevnikUpit = $upitDelete;
            $radnja = "Obrisana kategorija ceste";
            $tip_radnje = "2";
            $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);

            header("Location: admin_obrazac.php");
        }


        $upit2 = "SELECT korisnik.korisnik_id, korisnik.ime, korisnik.prezime, korisnik.korisnicko_ime, korisnik.status, uloga_korisnika.naziv FROM korisnik "
                . "INNER JOIN uloga_korisnika on korisnik.uloga_korisnika_uloga_korisnika_id=uloga_korisnika.uloga_korisnika_id";
        $rezultat2 = $veza->selectDB($upit2);
        $dataRow2 = "";
        while ($red2 = mysqli_fetch_array($rezultat2)) {
            $dataRow2 = $dataRow2 . "<tr><td><a href=\"$putanja/admin_obrazac.php?korisnicki_id={$red2['korisnik_id']}"
                    . "&korime={$red2['korisnicko_ime']}#popis\">"
                    . "$red2[0]</td><td>$red2[1]</td><td>$red2[2]</td><td>$red2[3]</td><td>$red2[4]</td><td>$red2[5]</td></tr>";
        }

        if (isset($_POST['submit4'])) {
            $korisnicki_id = $_REQUEST['korisnicki_id'];
            $greska = "";

            foreach ($_POST as $k => $v) {
                if (empty($v)) {
                    $greska .= "Nije popunjeno: $k <br>";
                }
            }
            if (empty($greska)) {

                $upitUpdate2 = "UPDATE `korisnik` SET `uloga_korisnika_uloga_korisnika_id` = '2' WHERE `korisnik`.`korisnik_id` = $korisnicki_id;";

                $rezultat5 = $veza->selectDB($upitUpdate2);

                $dnevnikUpit = $upitUpdate2;
                $radnja = "Dodijeljena uloga moderatora registriranom korisniku";
                $tip_radnje = "2";
                $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);

                header("Location: admin_obrazac.php");
            }
        }

        $upit3 = "SELECT korisnik_id, ime, prezime, korisnicko_ime, GROUP_CONCAT(naziv_kategorije) FROM korisnik, kategorija_ceste, ureduje "
                . "WHERE kategorija_ceste.kategorija_ceste_id=ureduje.kategorija_ceste_kategorija_ceste_id "
                . "AND ureduje.korisnik_korisnik_id=korisnik.korisnik_id "
                . "AND korisnik.uloga_korisnika_uloga_korisnika_id=2 "
                . "GROUP BY korisnik.korisnik_id;";
        $rezultat3 = $veza->selectDB($upit3);
        $dataRow3 = "";
        while ($red3 = mysqli_fetch_array($rezultat3)) {
            $dataRow3 = $dataRow3 . "<tr><td><a href=\"$putanja/admin_obrazac.php?moderator_id={$red3['korisnik_id']}"
                    . "&modime={$red3['korisnicko_ime']}#moderatori\">"
                    . "$red3[0]</td><td><a href=\"$putanja/admin_obrazac.php?moderator_id={$red3['korisnik_id']}"
                    . "&modime={$red3['korisnicko_ime']}#moderatori\">"
                    . "$red3[1]</td><td>$red3[2]</td><td>$red3[3]</td><td>$red3[4]</td></tr>";
        }

        $upit4 = "SELECT DISTINCT korisnik_id, korisnik.prezime, korisnik.prezime, korisnik.korisnicko_ime FROM korisnik, uloga_korisnika "
                . "WHERE korisnik.uloga_korisnika_uloga_korisnika_id=2";
        $rezultat4 = $veza->selectDB($upit4);
        $dataRow4 = "";
        while ($red4 = mysqli_fetch_array($rezultat4)) {
            $dataRow4 = $dataRow4 . "<tr><td><a href=\"$putanja/admin_obrazac.php?moderator_id={$red4['korisnik_id']}"
                    . "&modime={$red4['korisnicko_ime']}#moderatori\">"
                    . "$red4[0]</td><td><a href=\"$putanja/admin_obrazac.php?moderator_id={$red4['korisnik_id']}"
                    . "&modime={$red4['korisnicko_ime']}#moderatori\">"
                    . "$red4[1]</td><td>$red4[2]</td><td>$red4[3]</td></tr>";
        }

        if (isset($_POST['submit5'])) {
            $moderator_id = $_REQUEST['moderator_id'];
            $kategorije_ceste = $_REQUEST['kategorija'];

            $upitID = "SELECT kategorija_ceste.kategorija_ceste_id FROM kategorija_ceste WHERE kategorija_ceste.naziv_kategorije = \"$kategorije_ceste\"";
            $rezultat10 = $veza->selectDB($upitID);



            $kategorija_id = 0;
            while ($red10 = mysqli_fetch_array($rezultat10)) {
                $kategorija_id = $red10[0];
            }
            $greska = "";

            foreach ($_POST as $k => $v) {
                if (empty($v)) {
                    $greska .= "Nije popunjeno: $k <br>";
                }
            }
            if (empty($greska)) {

                $upitInsert2 = "INSERT INTO `ureduje` (`korisnik_korisnik_id`, `kategorija_ceste_kategorija_ceste_id`) VALUES ('{$moderator_id}', '{$kategorija_id}');";

                $rezultat6 = $veza->selectDB($upitInsert2);

                $dnevnikUpit = $upitInsert2;
                $radnja = "Dodijeljena kategorija ceste moderatoru";
                $tip_radnje = "2";
                $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);


                header("Location: admin_obrazac.php");
            }
        }
        if (isset($_POST['submitKorisnik'])) {
            header("Location: ../forbidden/korisnici.php");
        }
    }
}
?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">
    <head>
        <title>Upravljanje</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="naslov" content="Promet">        
        <meta name="autor" content="Lovro Cmrecak">
        <meta name="keywords" content="promet, projekt, webdip, obrazac, admin, upravljanje">
        <meta name="opis" content="Stranica s obrascima za administratora projekta Promet. Kreirano 2.6.2021.">
        <link href='../css/lcmrecak.css' type="text/css" rel="stylesheet"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script>
            $(document).ready(function () {
                $("#myInput").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });

            $(document).ready(function () {
                $("#myInput2").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody2 tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
            $(document).ready(function () {
                $("#myInput3").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody3 tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
            $(document).ready(function () {
                $("#myInput4").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody4 tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
        </script>

    </head>
    <body>

        <header>
            <img src="../multimedija/instagram-logo.png" alt="instagram" width="30"/>
            <img src="../multimedija/facebook-logo.png" alt="facebook" width="30"/>
            <a href="../rss.php"><img src="../multimedija/rss-logo.png" alt="rss" width="30"/></a>
            <a href="#sadrzaj"><h1>UPRAVLJANJE PODACIMA</h1></a>

        </header>
        <nav id="navigacija">
            <?php
            include '../meni.php';
            ?>
        </nav>
        <section id="sadrzaj">
            <h2 style="text-align: center;padding-top: 4%; font-weight: bold;">Popis svih kategorija cesta</h2>
            <form style="margin-top: 0%">
                <input id="myInput" type="text" placeholder="Pretražite tablicu">
            </form>

            <table style="margin-top: 1%">

                <thead>
                    <tr>
                        <th>ID kategorije</th>
                        <th>Naziv kategorije</th>
                        <th>Opis kategorije</th>
                    </tr>

                </thead>
                <tbody id="tablicaBody">
                    <?php
                    echo $dataRow;
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4">PROMET</td>
                    </tr>
                </tfoot>

            </table>

            <form action="" method="post" id="form1" name="form1" style="margin-top: 1%">

                <?php
                if (isset($_GET['kategorija_id'])) {
                    if (isset($greska2)) {
                        echo "<p style='color:red'>$greska2";
                    }
                    echo "<h2 style=\"text-align:center\"><b>Ažurirajte kategoriju</b></h2>";
                    echo "<label for=\"kategorija_id\"><b>ID kategorije</b></label>
                    <input readonly type=\"text\" value=\"{$_GET['kategorija_id']}\" name=\"kategorija_id\" id=\"kategorija_id\">
                    <label for=\"naziv\"><b>Naziv kategorije</b></label>
                    <input type=\"text\" value=\"{$_GET['kategorija']}\" name=\"naziv\" id=\"naziv\">
                    <label for=\"opis\"><b>Opis kategorije</b></label>
                    <input type=\"text\" value=\"{$_GET['opis']}\" name=\"opis\" id=\"opis\">
                    <input name=\"submit6\" id=\"submit6\" type=\"submit\" value=\"Ažuriraj kategoriju\">"
                    . "<input name=\"submit3\" id=\"submit3\" type=\"submit\" value=\"Obriši kategoriju\" style=\"background-color:red\">";
                } else {
                    if (isset($greska)) {
                        echo "<p style='color:red'>$greska";
                    }
                    echo "<h2 style=\"text-align:center\"><b>Kliknite na oznaku ceste za promjenu statusa ili unesite novu kategoriju</b></h2>";
                    echo "<label for=\"naziv\"><b>Naziv kategorije</b></label>";
                    echo "<input type=\"text\" name=\"naziv\" id=\"naziv\">
                    <label for=\"opis\"><b>Opis kategorije</b></label>
                    <input type=\"text\"  name=\"opis\" id=\"opis\">
                    <input name=\"submit2\" id=\"submit2\" type=\"submit\" value=\"Dodaj kategoriju\">";
                }
                ?>

            </form>
            <h2 style="text-align: center;padding-top: 4%; font-weight: bold;" id="popis">Popis svih korisnika</h2>
            <form style="margin-top: 0%" method="post" action="">
                <input id="korisnici" type="submit" name="submitKorisnik" value="Prikaži popis svih korisnika">
            </form>

            <form action="" method="post" id="form1" name="form1" style="margin-top: 1%">

                <?php
                if (isset($_GET['korisnicki_id'])) {
                    if (isset($greska)) {
                        echo "<p style='color:red'>$greska";
                    }
                    echo "<h2 style=\"text-align:center\"><b>Dodijeli moderatora</b></h2>";
                    echo "<label for=\"korime\"><b>Korisnik</b></label>
                    <input readonly type=\"text\" value=\"{$_GET['korime']}\" name=\"korime\" id=\"korime\">

                    <input name=\"submit4\" id=\"submit4\" type=\"submit\" value=\"Dodijeli ulogu moderatora\">";
                }
                ?>

            </form>

            <h2 style="text-align: center;padding-top: 4%; font-weight: bold;">Popis moderatora s dodijeljenim kategorijama</h2>
            <form style="margin-top: 0%">
                <input id="myInput3" type="text" placeholder="Pretražite tablicu">
            </form>
            <table style="margin-top: 1%">

                <thead>
                    <tr>
                        <th>ID moderatora</th>
                        <th>Ime moderatora</th>
                        <th>Prezime moderatora</th>
                        <th>Korisničko ime</th>
                        <th>Kategorije kojima upravlja</th>

                    </tr>

                </thead>
                <tbody id="tablicaBody3">
                    <?php
                    echo $dataRow3;
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="5">PROMET</td>
                    </tr>
                </tfoot>

            </table>

            <h2 style="text-align: center;padding-top: 4%; font-weight: bold;">Popis svih moderatora</h2>
            <form style="margin-top: 0%">
                <input id="myInput4" type="text" placeholder="Pretražite tablicu">
            </form>
            <table style="margin-top: 1%">

                <thead>
                    <tr>
                        <th>ID moderatora</th>
                        <th>Ime moderatora</th>
                        <th>Prezime moderatora</th>
                        <th>Korisničko ime</th>

                    </tr>

                </thead>
                <tbody id="tablicaBody4">
                    <?php
                    echo $dataRow4;
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="5">PROMET</td>
                    </tr>
                </tfoot>

            </table>

            <form action="" method="post" id="form1" name="form1" style="margin-top: 1%">

                <?php
                if (isset($_GET['moderator_id'])) {
                    if (isset($greska)) {
                        echo "<p style='color:red'>$greska";
                    }
                    echo "<h2 style=\"text-align:center\" id=\"moderatori\"><b>Dodijeli kategoriju</b></h2>";
                    echo "<label for=\"modime\"><b>Moderator</b></label>
                    <input readonly type=\"text\" value=\"{$_GET['modime']}\" name=\"modime\" id=\"modime\">
                        <label for=\"kategorija\"><b>Kategorija ceste</b></label>
                    <select id=\"kategorija\" name=\"kategorija\" placeholder=\"Kategorija ceste..\">
                    <option selected></option>";

                    $db = "SELECT DISTINCT naziv_kategorije FROM kategorija_ceste";
                    $rezultat9 = $veza->selectDB($db);

                    while ($data = mysqli_fetch_array($rezultat9)) {
                        echo "<option name=\"kategorija\" value='{$data["naziv_kategorije"]}'>" . $data['naziv_kategorije'] . "</option>";
                    }
                    echo "</select>";

                    echo "<input name=\"submit5\" id=\"submit5\" type=\"submit\" value=\"Dodijeli kategoriju\">";
                }
                ?>

            </form>


        </section>
        <br>
        <br>
        <br>
        <br>
    <div class="footer">
        <p>&copy;2020 Lovro Cmrečak</a></p>
    </div>


    </body>
</html>