<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$putanja = dirname($_SERVER["REQUEST_URI"]);
$direktorij = dirname(getcwd());
include '../zaglavlje.php';
include '../dnevnik_rada.php';
$dnevnik = new Dnevnik();

if (!isset($_SESSION["uloga"])) {
    header("Location: index.php");
    exit();
} elseif (isset($_SESSION["uloga"]) && $_SESSION["uloga"] > 3) {
    header("Location: ../index.php");
} else {
    if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] <= 3) {
        $veza = new Baza();
        $veza->spojiDB();

        $korisnik = $_SESSION["korisnik"];
        $upit3 = "SELECT korisnik.korisnik_id FROM korisnik WHERE korisnik.korisnicko_ime = '{$korisnik}'";

        $rezultat3 = $veza->selectDB($upit3);

        $ID_korisnika = 0;
        while ($red1 = mysqli_fetch_array($rezultat3)) {
            $ID_korisnika = $red1[0];
        }

        $upit4 = "SELECT vrsta_dokumenta, naziv_dokumenta, vrijeme_prijenosa, `status` FROM dokument WHERE dokument.status = 'P'";
        $rezultat4 = $veza->selectDB($upit4);
        $dataRow4 = "";
        while ($red4 = mysqli_fetch_array($rezultat4)) {
            $dataRow4 = $dataRow4 . "<tr><td>$red4[0]</td><td>$red4[1]</td><td>$red4[2]</td><td>$red4[3]</td></tr>";
        }

        $upit5 = "SELECT vrsta_dokumenta, naziv_dokumenta,vrijeme_prijenosa, status FROM dokument";
        $rezultat5 = $veza->selectDB($upit5);
        $dataRow5 = "";
        while ($red5 = mysqli_fetch_array($rezultat5)) {
            if ($red5[3] == 'P') {
                $dataRow5 = $dataRow5 . "<tr><td>$red5[0]</td><td><a href=\"$putanja/dokument_obrazac.php?naziv={$red5['naziv_dokumenta']}&status={$red5['status']}\">$red5[1]</td><td>$red5[2]</td><td >$red5[3]</td></tr>";
            }
            if ($red5[3] == 'N') {
                $dataRow5 = $dataRow5 . "<tr><td>$red5[0]</td><td><a href=\"$putanja/dokument_obrazac.php?naziv={$red5['naziv_dokumenta']}&status={$red5['status']}\">$red5[1]</td><td>$red5[2]</td><td style=\"background-color: orange\">$red5[3]</td></tr>";
            }
            if ($red5[3] == 'O') {
                $dataRow5 = $dataRow5 . "<tr><td>$red5[0]</td><td><a href=\"$putanja/dokument_obrazac.php?naziv={$red5['naziv_dokumenta']}&status={$red5['status']}\">$red5[1]</td><td>$red5[2]</td><td style=\"background-color: red\">$red5[3]</td></tr>";
            }
        }




        if (isset($_POST["posalji"])) {
            $userfile = $_FILES['cv']['tmp_name'];
            $userfile_name = $_FILES['cv']['name'];
            $userfile_size = $_FILES['cv']['size'];
            $userfile_type = $_FILES['cv']['type'];
            $userfile_error = $_FILES['cv']['error'];


            $upfile = '../dokumenti/' . $userfile_name;

            $oznaka = $_POST['oznaka'];
            $upit = "SELECT cesta.cesta_id FROM cesta WHERE cesta.oznaka = '{$oznaka}'";

            $rezultat = $veza->selectDB($upit);

            $cesta_id = 0;
            while ($red2 = mysqli_fetch_array($rezultat)) {
                $cesta_id = $red2[0];
            }

            $date = date('Y-m-d H:i:s');
            $greska = "";

            foreach ($_POST as $k => $v) {
                if (empty($v)) {
                    $greska .= "Nije popunjeno: $k <br>";
                }
            }
            if (empty($greska)) {

                $upit2 = "INSERT INTO `dokument` (`dokument_id`, `naziv_dokumenta`, `vrsta_dokumenta`, `status`, `vrijeme_prijenosa`, `cesta_cesta_id`, `korisnik_korisnik_id`) 
                VALUES (NULL, '{$userfile_name}', '{$userfile_type}', 'N', '{$date}', '{$cesta_id}', '{$ID_korisnika}');
";

                $rezultat = $veza->selectDB($upit2);

                if (is_uploaded_file($userfile)) {
                    if (!move_uploaded_file($userfile, $upfile)) {
                        echo 'Problem: nije moguće prenijeti datoteku na odredište';
                        exit;
                    }
                } else {
                    echo 'Problem: mogući napad prijenosom. Datoteka: ' . $userfile_name;
                    exit;
                }


                $dnevnikUpit = $upit2;
                $radnja = "Prenesena datoteka i upisana u bazu";
                $tip_radnje = "2";
                $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);

                header("Location: dokument_obrazac.php ");
            }
        }

        if (isset($_POST['submit2'])) {
            $naziv = $_REQUEST['naziv'];
            $upitID = "SELECT dokument.dokument_id FROM dokument WHERE dokument.naziv_dokumenta = \"$naziv\"";
            $rezultat6 = $veza->selectDB($upitID);

            $dokument_id = "";
            while ($red6 = mysqli_fetch_array($rezultat6)) {
                $dokument_id = $red6[0];
            }


            $status = $_REQUEST['status'];

            $upitUpdate = "UPDATE `dokument` SET `status` = '{$status}' "
                    . "WHERE `dokument`.`dokument_id` = {$dokument_id}";

            $rezultat7 = $veza->selectDB($upitUpdate);

            $dnevnikUpit = $upitUpdate;
            $radnja = "Ažuriran status dokumenta";
            $tip_radnje = "2";
            $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);

            header("Location: dokument_obrazac.php");
        }
    }
}
?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">
    <head>
        <title>Dokumentiraj</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="naslov" content="Promet">        
        <meta name="autor" content="Lovro Cmrecak">
        <meta name="keywords" content="promet, projekt, webdip, evidencija, prijava, problem">
        <meta name="opis" content="Stranica s obrascem za evidenciju i prijavu problema projekta Promet. Kreirano 2.6.2021.">
        <link href='../css/lcmrecak.css' type="text/css" rel="stylesheet"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script>
            $(document).ready(function () {
                $("#myInput").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
        </script>

    </head>
    <body>

        <header>
            <img src="../multimedija/instagram-logo.png" alt="instagram" width="30"/>
            <img src="../multimedija/facebook-logo.png" alt="facebook" width="30"/>
            <a href="../rss.php"><img src="../multimedija/rss-logo.png" alt="rss" width="30"/></a>
            <a href="#sadrzaj"><h1>DODAVANJE DOKUMENTA</h1></a>

        </header>
        <nav id="navigacija">
            <?php
            include '../meni.php';
            ?>
        </nav>
        <section id="sadrzaj">

            <form name="obrazac" id="obrazac" method="post" enctype="multipart/form-data"
                  action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <fieldset>
                    <label for="oznaka"><b>Unesite oznaku ceste:</b></label>
                    <?php
                    if (isset($greska)) {
                        echo "<p style='color:red'>$greska";
                    }
                    echo "<input type=\"text\" placeholder=\"Unesite oznaku ceste...\" name=\"oznaka\" id=\"oznaka\">";
                    ?>
                    <label for="cv">Datoteka: </label>
                    <input type="file" name="cv" />
                    <input type="hidden" name="MAX_FILE_SIZE" value="30000"/>
                    <input type="submit" name="posalji" value="Prenesi dokument"/>
                </fieldset>
            </form>

            <form style="margin-top: 0%">
                <h2 style="text-align: center;padding-top: 4%; font-weight: bold;">Popis potvrđenih dokumenata</h2>


                <label for="oznaka"><b>Filtrirajte po vrsti dokumenta:</b></label><br>
                <select id="unos" onchange="filter()" placeholder="Search for names..">
                    <option  selected></option>
                    <?php
                    $veza = new Baza();
                    $veza->spojiDB();
                    $db = "SELECT DISTINCT vrsta_dokumenta FROM dokument";
                    $rezultat9 = $veza->selectDB($db);

                    while ($data = mysqli_fetch_array($rezultat9)) {
                        echo "<option value='" . $data['vrsta_dokumenta'] . "'>" . $data['vrsta_dokumenta'] . "</option>";
                    }
                    ?>
                </select>
            </form>
            <table id="tablica1" style="margin-top: 1%">

                <thead>
                    <tr>
                        <th>Vrsta dokumenta</th>
                        <th>Naziv dokumenta</th>
                        <th>Datum prijenosa</th>
                        <th>Status (potvrđen/nepotvrđen/odbijen)</th>
                    </tr>

                </thead>
                <tbody>
                    <?php
                    echo $dataRow4;
                    ?>

                </tbody>
                <tfoot>

                </tfoot>

            </table>

            <h2 style="text-align: center;padding-top: 4%; font-weight: bold;">Popis dokumenata</h2>
            <form style="margin-top: 0%">
                <input id="myInput" type="text" placeholder="Pretražite tablicu">
            </form>
            <table id="tablica2" style="margin-top: 1%">

                <thead>
                    <tr>
                        <th>Vrsta dokumenta</th>
                        <th>Naziv dokumenta</th>
                        <th>Datum prijenosa</th>
                        <th>Status (potvrđen/nepotvrđen/odbijen)</th>
                    </tr>

                </thead>
                <tbody id="tablicaBody">
                    <?php
                    echo $dataRow5;
                    ?>

                </tbody>
                <tfoot>

                </tfoot>

            </table>

            <?php
            if (isset($_GET['naziv'])) {
                $status = $_GET['status'];
                echo "<form action=\"\" method=\"post\" id=\"form2\" name=\"form2\" style=\"margin-top: 1%\">
                <h3 style=\"text-align: center;padding-bottom: 2%;\">Evidentiraj obilazak</h3>

                <label for=\"oznaka\"><b>Unesite oznaku ceste ili kliknite na oznaku u tablici:</b></label>
                
                <input readonly type=\"text\" value=\"{$_GET['naziv']}\" name=\"oznaka\" id=\"oznaka\">
                <label for=\"status\"><b>Status</b></label>
                    <select id=\"status\" name=\"status\" placeholder=\"Status..\">
                    <option  selected=\"selected\">$status</option>
                    <option  disabled>-------------------------------</option>
                    <option  value=\"O\">Odbij</option>
                    <option  value=\"P\">Prihvati</option>
                    </select>
                    <input name=\"submit2\" id=\"submit2\" type=\"submit\" value=\"Ažuriraj status\">";
            } else {
                echo "<h3 style=\"text-align: center;padding-bottom: 2%;\">Klikni na naziv dokumenta da urediš status</h3>";
            }
            ?>

        </form>

        <script>
            function filter() {
                var input, filter, table, tr, td, i, txtValue;
                input = document.getElementById("unos");
                filter = input.value.toUpperCase();
                table = document.getElementById("tablica1");
                tr = table.getElementsByTagName("tr");
                for (i = 0; i < tr.length; i++) {
                    td = tr[i].getElementsByTagName("td")[0];
                    if (td) {
                        txtValue = td.textContent || td.innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                        } else {
                            tr[i].style.display = "none";
                        }
                    }
                }
            }
        </script>

    </section>
        <br>
        <br>
        <br>
        <br>
    <div class="footer">
        <p>&copy;2020 Lovro Cmrečak</a></p>
    </div>


</body>
</html>