<?php
 
  if(!empty($_POST['g-recaptcha-response']))
  {
        $secret = '6Lfc_wwbAAAAADNim03TnkKx8TNVvoivk7Sfijy5';
        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
        $responseData = json_decode($verifyResponse);
        if($responseData->success)
            header ("Location: ../index.php");
       
        else
            header ("Location: registracija.php");
       echo $message;
   }
?>