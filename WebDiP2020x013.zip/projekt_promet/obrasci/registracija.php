<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$putanja = dirname($_SERVER["REQUEST_URI"]);
$direktorij = dirname(getcwd());
if(isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on"){
    header("Location: http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"], true, 301);
    exit;
    }

include '../zaglavlje.php';
include '../dnevnik_rada.php';
$dnevnik = new Dnevnik();

if (isset($_POST['submit'])) {
    $robot="";
    
    if(isset($_POST['g-recaptcha-response'])){
        $captcha=$_POST['g-recaptcha-response'];
    }
    
    if(!$captcha||empty($captcha)){
        $robot="Označite da niste robot.";
    }
    
    $secretKey = '6Lfc_wwbAAAAADNim03TnkKx8TNVvoivk7Sfijy5';
    $ip=$_SERVER['REMOTE_ADDR'];
    
    $url= 'https://www.google.com/recaptcha/api/siteverify?secret='.urlencode($secretKey).'&response='.urlencode($captcha);
    $response= file_get_contents($url);
    $responseKeys= json_decode($response, true);
    
    if(!$responseKeys["success"]){
        header("Location: registracija.php?robot=1");
        
    }
    
    $imePostoji = "";
    if (isset($_POST['korime'])) {
        $name = $_POST['korime'];

        $checkdata = " SELECT korisnicko_ime FROM korisnik WHERE korisnicko_ime='$name' ";
        $veza = new Baza();
        $veza->spojiDB();
        $query = $veza->selectDB($checkdata);

        if (mysqli_num_rows($query) > 0) {
            $imePostoji = "Korisničko ime već postoji!";
        }
    }

    $greska = "";
    $greska2 = "";
    $greska3 = "";
    $greska4 = "";

    foreach ($_POST as $k => $v) {
        if ($k == 'korime') {
            if (empty($v)) {
                $greska .= "Nije popunjeno: korisničko ime <br>";
            }
        }
        if ($k == 'mail') {
            if (empty($v)) {
                $greska2 .= "Nije popunjeno: mail<br>";
            }
        }
        if ($k == 'lozinka') {
            if (empty($v)) {
                $greska3 .= "Nije popunjeno: lozinka<br>";
            }
        }
        if ($k == 'plozinka') {
            if (empty($v)) {
                $greska4 .= "Nije popunjeno: ponovljena lozinka<br>";
            }
        }
    }
    if (empty($greska) && empty($greska2) && empty($greska3) && empty($greska4)&&empty($imePostoji)&&$responseKeys["success"]) {
        $veza = new Baza();
        $veza->spojiDB();

        $ime = $_REQUEST['ime'];
        $prezime = $_REQUEST['prezime'];
        $korime = $_REQUEST['korime'];
        $lozinka = $_REQUEST['lozinka'];
        $lozinka2 = $_REQUEST['plozinka'];
        $lozinka_sha256 = hash('sha256', $lozinka);
        $email = $_REQUEST['mail'];
        $date = date('Y-m-d H:i:s');
        
        $regexIme="/\b([A-ZÀ-ÿ][-,a-z. ']+[ ]*)+/";
        $regexPrezime="/\b([A-ZÀ-ÿ][-,a-z. ']+[ ]*)+/";
        $regexKorime="^.{5,}$^";
        $regexLozinka="^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{6,}$^";
        $regexEmail="^[\w\-\.]+@([\w\-]+\.)+[\w\-]{2,4}$^";

        $nezadovoljenUvjet="";
        
        if($lozinka==$lozinka2
                &&preg_match($regexIme, $ime)
                &&preg_match($regexPrezime, $prezime)
                &&preg_match($regexKorime, $korime)
                &&preg_match($regexLozinka, $lozinka)
                &&preg_match($regexEmail, $email)){
        $upit = "INSERT INTO `korisnik` (`korisnik_id`, `ime`, `prezime`, `korisnicko_ime`, `lozinka`, `lozinka_sha56`, `email`, `status`, `datum_registracije`, `broj_neuspjesnih_prijava`, `uvjeti_koristenja`, `uloga_korisnika_uloga_korisnika_id`) VALUES "
                . "(NULL, '$ime', '$prezime', '$korime', '$lozinka', '$lozinka_sha256', '$email', '1', '$date', '0', 'prihvaceni', '3');";

        $rezultat = $veza->selectDB($upit);

        $korime1 = 'korime';
        $uloga = '3';

        Sesija::kreirajKorisnika($korime1, $uloga);
       
        header("Location: ../index.php");

        }
        else{
            $nezadovoljenUvjet="Jedan od uvjeta nije zadovoljen";
        }
    }
}
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html lang="hr">
    <head>
        <title>Registracija</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="naslov" content="Promet">        
        <meta name="autor" content="Lovro Cmrecak">
        <meta name="keywords" content="promet, projekt, webdip, registracija">
        <meta name="opis" content="Stranica za registraciju projekta Promet. Kreirano 2.6.2021.">
        <link href='../css/lcmrecak.css' type="text/css" rel="stylesheet"/>
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>

        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript">

            function checkname()
            {
                var name = document.getElementById("korime").value;

                if (name)
                {
                    $.ajax({
                        type: 'post',
                        url: 'checkdata.php',
                        data: {
                            user_name: name,
                        },
                        success: function (response) {
                            $('#name_status').html(response);
                            if (response == "OK")
                            {
                                return true;
                            } else
                            {
                                return false;
                            }
                        }
                    });
                } else
                {
                    $('#name_status').html("");
                    return false;
                }
            }
        </script>

    </head>


    <body>
        <header>
            <img src="../multimedija/instagram-logo.png" alt="instagram" width="30"/>
            <img src="../multimedija/facebook-logo.png" alt="facebook" width="30"/>
            <a href="../rss.php"><img src="../multimedija/rss-logo.png" alt="rss" width="30"/></a>
            <a href="#sadrzaj"><h1>REGISTRACIJA</h1></a>

        </header>
        <nav id="navigacija">
<?php
include '../meni.php';
if(!empty($imePostoji)){
echo "<script>alert(\"{$imePostoji}\")</script>";
}
?>
        </nav>
        <section id="sadrzaj">
<?php
if (isset($nezadovoljenUvjet)) {
    echo "<p style=\"color:red\">$nezadovoljenUvjet</p>";
}
?>
            <form id="form" action="" method="post">

                <div class="container">
                    <h2 style="text-align: center;padding-bottom: 2%">Registrirajte se</h2>
                    <label for="ime"><b>Ime</b></label>
                    <input type="text" placeholder="Ime u obliku 'Ime'" name="ime" id="ime" autofocus>

                    <label for="prezime"><b>Prezime</b></label>
                    <input type="text" placeholder="Prezime u obliku 'Prezime'" name="prezime" id="prezime">

                    <label for="korime"><b>Korisničko ime <?php
if (isset($greska)) {
    echo "<p style=\"color:red\">$greska</p>";
}
?></b></label>
                    <input type="text" placeholder="Korisničko ime mora imati minimalno 5 znakova" name="korime" id="korime" >

                    <label for="mail"><b>E-mail <?php
                            if (isset($greska2)) {
                                echo "<p style=\"color:red\">$greska2</p>";
                            }
                            ?></b></label>
                    <input type="email" placeholder="E-mail u obliku 'example@gmail.com'" name="mail" id="mail" >

                    <label for="lozinka"><b>Lozinka <?php
                            if (isset($greska3)) {
                                echo "<p style=\"color:red\">$greska3</p>";
                            }
                            ?></b></label>
                    <input type="password" placeholder="Lozinka mora imati minimalno 6 znakova, broj, veliko i malo slovo" name="lozinka" id="lozinka" >

                    <label for="plozinka"><b>Ponovite lozinku <?php
                            if (isset($greska4)) {
                                echo "<p style=\"color:red\">$greska4</p>";
                            }
                            ?></b></label>
                    <input type="password" placeholder="Ponovite lozinku..." name="plozinka" id="plozinka" >
                    Prihvaćam uvjete korištenja <input type="checkbox" id="myCheck" name="test" required>
                    <p id="demo"></p>
                    <div class="g-recaptcha" data-sitekey="6Lfc_wwbAAAAAC21jUFT4FFHcLfaStbmDJzDB6tO"></div>
                    <?php
                            if (isset($_GET['robot'])) {
                                echo "<p>Označite da niste robot!</p>";
                            }
                            ?>

                    <input type="submit" value="Registriraj se" onlclick="uvjetiKoristenja" name="submit" id="submit">
                </div>
            </form>


        </section>
        <script>
function uvjetiKoristenja() {
  var x = document.getElementById("myCheck").required;
  document.getElementById("demo").innerHTML = x;
}
</script>
        <br>
        <br>
        <br>
        <br>
    <div class="footer">
        <p>&copy;2020 Lovro Cmrečak</a></p>
    </div>


    </body>
</html>
