<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$putanja = dirname($_SERVER["REQUEST_URI"]);
$direktorij = dirname(getcwd());
include '../zaglavlje.php';
include '../dnevnik_rada.php';
$dnevnik = new Dnevnik();

if (!isset($_SESSION["uloga"])) {
    header("Location: index.php");
    exit();
} elseif (isset($_SESSION["uloga"]) && $_SESSION["uloga"] > 3) {
    header("Location: ../index.php");
} else {
    if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] <= 3) {
        $veza = new Baza();
        $veza->spojiDB();

        $korisnik = $_SESSION["korisnik"];
        $upit3 = "SELECT korisnik.korisnik_id FROM korisnik WHERE korisnik.korisnicko_ime = '{$korisnik}'";

        $rezultat3 = $veza->selectDB($upit3);

        $ID_korisnika = 0;
        while ($red1 = mysqli_fetch_array($rezultat3)) {
            $ID_korisnika = $red1[0];
        }

        $upit = "SELECT cesta.oznaka, cesta.pocetak_dionice, cesta.zavrsetak_dionice, kategorija_ceste.naziv_kategorije FROM cesta, kategorija_ceste "
                . "WHERE cesta.kategorija_ceste_kategorija_ceste_id=kategorija_ceste.kategorija_ceste_id AND cesta.status = 'O'"
                . "ORDER BY cesta.kategorija_ceste_kategorija_ceste_id";
        $rezultat = $veza->selectDB($upit);
        $dataRow = "";
        while ($red = mysqli_fetch_array($rezultat)) {
            $dataRow = $dataRow . "<tr><td><a href=\"$putanja/evidencija_problem.php?oznaka={$red['oznaka']}\">$red[0]</td><td>$red[1]</td><td>$red[2]</td><td>$red[3]</td></tr>";
        }


        $upit4 = "SELECT pocetak_dionice, zavrsetak_dionice, broj_kilometara FROM cesta, obilazak "
                . "WHERE obilazak.korisnik_korisnik_id=$ID_korisnika AND obilazak.cesta_cesta_id=cesta.cesta_id";
        $rezultat4 = $veza->selectDB($upit4);
        $dataRow4 = "";
        while ($red4 = mysqli_fetch_array($rezultat4)) {
            $dataRow4 = $dataRow4 . "<tr><td>$red4[0]</td><td>$red4[1]</td><td>$red4[2]</td></tr>";
        }
        $upit5 = "SELECT SUM(broj_kilometara) FROM cesta, obilazak WHERE obilazak.korisnik_korisnik_id={$ID_korisnika} AND obilazak.cesta_cesta_id=cesta.cesta_id";
        $rezultat5 = $veza->selectDB($upit5);
        $dataRow5 = "";
        while ($red5 = mysqli_fetch_array($rezultat5)) {
            $dataRow5 = $dataRow5 . "<tr><td colspan=\"2\" style=\"text-align:left; font-weight: bold;\">Ukupno prijeđeno:</td><td style=\"font-weight: bold\">$red5[0]</td></tr>";
        }


        if (isset($_POST['submit'])) {
            $greska = "";

            $oznaka = $_REQUEST['oznaka'];

            $upit = "SELECT cesta.cesta_id FROM cesta WHERE cesta.oznaka = '{$oznaka}' AND cesta.status='O'";

            $rezultat = $veza->selectDB($upit);

            $cesta_id = "";
            while ($red2 = mysqli_fetch_array($rezultat)) {
                $cesta_id = $red2[0];
            }

            if (!empty($cesta_id)) {
                $upit2 = "INSERT INTO `obilazak` (`obilazak_id`, `cesta_cesta_id`, `korisnik_korisnik_id`) VALUES (NULL, '{$cesta_id}', '{$ID_korisnika}');";

                $rezultat2 = $veza->selectDB($upit2);

                $dnevnikUpit = $upit2;
                $radnja = "Dodan novi obilazak";
                $tip_radnje = "2";
                $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);
            }

            header("Location: evidencija_problem.php");
        }

        if (isset($_POST['submit2'])) {
            $greska = "";

            $oznaka = $_REQUEST['oznaka'];
            $naziv = $_REQUEST['naziv'];
            $opis = $_REQUEST['opis'];
            $date = date('Y-m-d H:i:s');

            $upit = "SELECT cesta.cesta_id FROM cesta WHERE cesta.oznaka = '{$oznaka}' AND cesta.status='O'";

            $rezultat = $veza->selectDB($upit);

            $cesta_id = 0;
            while ($red2 = mysqli_fetch_array($rezultat)) {
                $cesta_id = $red2[0];
            }

            if (!empty("cesta_id")) {
                $upit2 = "INSERT INTO `problem` (`problem_id`, `naziv_problema`, `opis`, `datum_vrijeme`, `cesta_id`, `korisnik_id`) "
                        . "VALUES (NULL, '{$naziv}', '{$opis}', '{$date}', '{$cesta_id}', '{$ID_korisnika}');";

                $rezultat2 = $veza->selectDB($upit2);

                $dnevnikUpit = $upit2;
                $radnja = "Dodan novi problem";
                $tip_radnje = "2";
                $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);
            }

            //  header("Location: evidencija_problem.php");
        }
    }
}
?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">
    <head>
        <title>Evidencija / problem</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="naslov" content="Promet">        
        <meta name="autor" content="Lovro Cmrecak">
        <meta name="keywords" content="promet, projekt, webdip, evidencija, prijava, problem">
        <meta name="opis" content="Stranica s obrascem za evidenciju i prijavu problema projekta Promet. Kreirano 2.6.2021.">
        <link href='../css/lcmrecak.css' type="text/css" rel="stylesheet"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script>
            $(document).ready(function () {
                $("#myInput").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
            $(document).ready(function () {
                $("#myInput2").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody2 tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
        </script>

    </head>
    <body>

        <header>
            <img src="../multimedija/instagram-logo.png" alt="instagram" width="30"/>
            <img src="../multimedija/facebook-logo.png" alt="facebook" width="30"/>
            <a href="../rss.php"><img src="../multimedija/rss-logo.png" alt="rss" width="30"/></a>
            <a href="#sadrzaj"><h1>EVIDENCIJA OBILAZAKA I PRIJAVA PROBLEMA</h1></a>

        </header>
        <nav id="navigacija">
<?php
include '../meni.php';
?>
        </nav>
        <section id="sadrzaj">
            <h2 style="text-align: center;padding-top: 4%; font-weight: bold;">Popis vaših obilazaka</h2>
            <form style="margin-top: 0%">
                <input id="myInput" type="text" placeholder="Pretražite tablicu">
            </form>

            <table style="margin-top: 1%">

                <thead>
                    <tr>
                        <th>Početak dionice</th>
                        <th>Kraj dionice</th>
                        <th>Broj kilometara</th>
                    </tr>

                </thead>
                <tbody id="tablicaBody">
<?php
echo $dataRow4;
echo$dataRow5;
?>

                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4">PROMET</td>
                    </tr>
                </tfoot>

            </table>

            <h2 style="text-align: center;padding-top: 4%; font-weight: bold;">Popis otvorenih dionica</h2>
            <form style="margin-top: 0%">
                <input id="myInput2" type="text" placeholder="Pretražite tablicu">
            </form>

            <table style="margin-top: 1%">

                <thead>
                    <tr>
                        <th>Oznaka ceste</th>
                        <th>Početak dionice</th>
                        <th>Kraj dionice</th>
                        <th>Kategorija ceste</th>
                    </tr>

                </thead>
                <tbody id="tablicaBody2">
<?php
echo $dataRow;
?>

                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4">PROMET</td>
                    </tr>
                </tfoot>

            </table>

            <form action="" method="post" id="form2" name="form2" style="margin-top: 1%">
                <h3 style="text-align: center;padding-bottom: 2%;" id="naslov">Dodaj obilazak</h3>
<?php
if (isset($greska2)) {
    echo "<p style='color:red'>$greska2</p>";
}
?>
                <label for="oznaka"><b>Unesite oznaku ceste ili kliknite na oznaku u tablici:</b></label>
                <?php
                if (isset($_GET['oznaka'])) {
                    echo "<input type=\"text\" value=\"{$_GET['oznaka']}\" name=\"oznaka\" id=\"oznaka\">";
                } else {
                    echo "<input type=\"text\" placeholder=\"Unesite oznaku ceste...\" name=\"oznaka\" id=\"oznaka\">";
                }
                ?>

                <input name="submit" id="submit" type="submit" value="Dodaj obilazak">

            </form>


            <form action="" method="post" id="form2" name="form2" style="margin-top: 1%">
                <h3 style="text-align: center;padding-bottom: 2%;" id="naslov">Prijavi problem</h3>
<?php
if (isset($greska2)) {
    echo "<p style='color:red'>$greska2</p>";
}
?>
                <label for="oznaka"><b>Unesite oznaku ceste ili kliknite na oznaku u tablici:</b></label>
                <?php
                if (isset($_GET['oznaka'])) {
                    echo "<input type=\"text\" value=\"{$_GET['oznaka']}\" name=\"oznaka\" id=\"oznaka\">";
                    echo "<label for=\"naziv\"><b>Naziv problema:</b></label>";
                    echo "<input type=\"text\" name=\"naziv\" id=\"naziv\">";
                    echo "<label for=\"opis\"><b>Opis problema:</b></label>";
                    echo "<input type=\"text\" name=\"opis\" id=\"opis\">";
                } else {
                    echo "<input type=\"text\" placeholder=\"Unesite oznaku ceste...\" name=\"oznaka\" id=\"oznaka\">";
                    echo "<label for=\"naziv\"><b>Naziv problema:</b></label>";
                    echo "<input type=\"text\" placeholder=\"Naziv problema...\" name=\"naziv\" id=\"naziv\">";
                    echo "<label for=\"opis\"><b>Opis problema:</b></label>";
                    echo "<input type=\"text\" placeholder=\"Opis problema\" name=\"opis\" id=\"opis\">";
                }
                ?>

                <input name="submit2" id="submit2" type="submit" value="Prijavi problem" style="background-color: red">

            </form>

        </section>
        <br>
        <br>
        <br>
        <br>
    <div class="footer">
        <p>&copy;2020 Lovro Cmrečak</a></p>
    </div>


    </body>
</html>