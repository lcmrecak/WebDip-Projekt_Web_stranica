<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$putanja = dirname($_SERVER["REQUEST_URI"]);
$direktorij = dirname(getcwd());
include './zaglavlje.php';
include './dnevnik_rada.php';
if (!isset($_SESSION["uloga"])) {
    header("Location: ../index.php");
    exit();
} elseif (isset($_SESSION["uloga"]) && $_SESSION["uloga"] > 1) {
    header("Location: ../index.php");
} else {
    if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] == 1) {
        $veza = new Baza();
        $veza->spojiDB();

        $upit = "SELECT korisnik.korisnicko_ime, dnevnik.radnja, dnevnik.datum_vrijeme, tip_radnje.naziv FROM korisnik, dnevnik, tip_radnje 
            WHERE korisnik.korisnik_id=dnevnik.korisnik_korisnik_id 
            AND dnevnik.tip_radnje_tip_radnje_id=tip_radnje.tip_radnje_id
            ORDER BY 3";
        $rezultat = $veza->selectDB($upit);
        $dataRow = "";
        while ($red = mysqli_fetch_array($rezultat)) {
            $dataRow = $dataRow . "<tr><td>$red[0]</td><td>$red[1]</td><td>$red[2]</td><td>$red[3]</td></tr>";
        }
    }
}
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html lang="hr">
    <head>
        <title>Statistika</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="naslov" content="Promet">        
        <meta name="autor" content="Lovro Cmrecak">
        <meta name="keywords" content="promet, projekt, webdip, statistika">
        <meta name="opis" content="Stranice statistike projekta Promet. Kreirano 2.6.2021.">
        <link href='css/lcmrecak.css' type="text/css" rel="stylesheet"/>    
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
<script>$(document).ready( function () {
    $('#tablica').DataTable();
} );</script>


    </head>
    <body>
        <header>
            <img src="multimedija/instagram-logo.png" alt="instagram" width="30"/>
            <img src="multimedija/facebook-logo.png" alt="facebook" width="30"/>
            <a href="rss.php"><img src="multimedija/rss-logo.png" alt="rss" width="30"/></a>
            <a href="#sadrzaj"><h1>STATISTIKA </h1></a>

        </header>
        <nav id="navigacija">
            <?php
            include './meni.php';
            ?>
        </nav>
        <img src="multimedija/road.jpg" alt="cesta" class="responsive" />
        <section id="sadrzaj"style="background-color: white">
            <h3>Statistika problema po kategorijama cesta</h3>
            <table id="tablica" class="noPrint" style="background-color: white;color:black;">

                <thead>
                    <tr>
                        <th>Korisnik</th>
                        <th>Radnja</th>
                        <th>Datum i vrijeme</th>
                        <th>Tip radnje</th>
                    </tr>

                </thead>
                <tbody id="tablicaBody">
                    <?php
                    echo $dataRow;
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4">PROMET</td>
                    </tr>
                </tfoot>

            </table>
            <button onclick="window.print();" class="noPrint">Prikaz za ispis</button>


        </section>
        <br>
        <br>
        <br>
        <br>
    <div class="footer">
        <p>&copy;2020 Lovro Cmrečak</a></p>
    </div>


    </body>
</html>
