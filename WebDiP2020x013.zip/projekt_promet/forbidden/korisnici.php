<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$putanja = dirname($_SERVER["REQUEST_URI"]);
$direktorij = dirname(getcwd());
include '../zaglavlje.php';
include '../dnevnik_rada.php';
$dnevnik = new Dnevnik();

if (!isset($_SESSION["uloga"])) {
    header("Location: ../index.php");
    exit();
} elseif (isset($_SESSION["uloga"]) && $_SESSION["uloga"] > 1) {
    header("Location: ../index.php");
} else {
    if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] == 1) {
        $veza = new Baza();
        $veza->spojiDB();
        $dnevnik = new Dnevnik();

        $upit2 = "SELECT korisnik.korisnik_id, korisnik.ime, korisnik.prezime, korisnik.korisnicko_ime, korisnik.status, uloga_korisnika.naziv FROM korisnik "
                . "INNER JOIN uloga_korisnika on korisnik.uloga_korisnika_uloga_korisnika_id=uloga_korisnika.uloga_korisnika_id";
        $rezultat2 = $veza->selectDB($upit2);
        $dataRow2 = "";
        while ($red2 = mysqli_fetch_array($rezultat2)) {
            $dataRow2 = $dataRow2 . "<tr><td><a href=\"$putanja/korisnici.php?korisnicki_id={$red2['korisnik_id']}"
                    . "&status={$red2['status']}&korisime={$red2['korisnicko_ime']}#popis\">"
                    . "$red2[0]</td><td>$red2[1]</td><td>$red2[2]</td><td>$red2[3]</td><td>$red2[4]</td><td>$red2[5]</td></tr>";
        }
        if (isset($_POST['submitKorisnik'])) {
            header("Location: ../obrasci/admin_obrazac.php");
        }
        
        if (isset($_POST['submit'])) {
            $korisnicki_id = $_REQUEST['korime'];
            $status1 = $_REQUEST['status'];

                $upitUpdate2 = "UPDATE `korisnik` SET `status` = '{$status1}' WHERE `korisnik`.`korisnik_id` = '{$korisnicki_id}';";

                $rezultat6 = $veza->selectDB($upitUpdate2);

                $dnevnikUpit = $upitUpdate2;
                $radnja = "Promijenjen status korisnika";
                $tip_radnje = "2";
                $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);


                header("Location: korisnici.php");
            
        }
        if (isset($_POST['submit9'])) {
            $korisnicki_id = $_REQUEST['korime'];
          
            

                $upitUpdate2 = "UPDATE `korisnik` SET `uloga_korisnika_uloga_korisnika_id` = '2' WHERE `korisnik`.`korisnik_id` = $korisnicki_id;";

                $rezultat5 = $veza->selectDB($upitUpdate2);

                $dnevnikUpit = $upitUpdate2;
                $radnja = "Dodijeljena uloga moderatora registriranom korisniku";
                $tip_radnje = "2";
                $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);

                header("Location: korisnici.php");
            
        }
    }
}
?>


<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">
    <head>
        <title>Popis korisnika</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="naslov" content="Promet">        
        <meta name="autor" content="Lovro Cmrecak">
        <meta name="keywords" content="promet, projekt, webdip, obrazac, admin, upravljanje">
        <meta name="opis" content="Stranica s popisom korisnika projekta Promet. Kreirano 2.6.2021.">
        <link href='../css/lcmrecak.css' type="text/css" rel="stylesheet"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script>

            $(document).ready(function () {
                $("#myInput2").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody2 tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });

        </script>

    </head>
    <body>

        <header>
            <img src="../multimedija/instagram-logo.png" alt="instagram" width="30"/>
            <img src="../multimedija/facebook-logo.png" alt="facebook" width="30"/>
            <a href="../rss.php"><img src="../multimedija/rss-logo.png" alt="rss" width="30"/></a>
            <a href="#sadrzaj"><h1>POPIS SVIH KORISNIKA</h1></a>

        </header>
        <nav id="navigacija">
            <?php
            include '../meni.php';
            ?>
        </nav>
        <section id="sadrzaj">
            <form style="margin-top: 0%" method="post" action="">
                <input id="korisnici" type="submit" name="submitKorisnik" value="Povratak na stranicu za upravljanje">
            </form>
            <h2 style="text-align: center;padding-top: 4%; font-weight: bold;" id="popis">Popis svih korisnika</h2>
            <form style="margin-top: 0%">
                <input id="myInput2" type="text" placeholder="Pretražite tablicu">
            </form>
            <table style="margin-top: 1%">


                <thead>
                    <tr>
                        <th>ID karisnika</th>
                        <th>Ime korisnika</th>
                        <th>Prezime korisnika</th>
                        <th>Korisničko ime</th>
                        <th>Status korisnika</th>
                        <th>Uloga korisnika</th>
                    </tr>

                </thead>
                <tbody id="tablicaBody2">
                    <?php
                    echo $dataRow2;
                    ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="6">PROMET</td>
                    </tr>
                </tfoot>

            </table>
            
            <form action="" method="post" id="form1" name="form1" style="margin-top: 1%">

                <?php
                if (isset($_GET['korisnicki_id'])) {
                    
                    $status = $_GET['status'];
                    echo "<h2 style=\"text-align:center\"><b>Ažuriraj status</b></h2>";
                    echo "<label for=\"korime\"><b>Korisnik</b></label>
                    <input readonly type=\"text\" value=\"{$_GET['korisnicki_id']}\" name=\"korime\" id=\"korime\">
                    <label for=\"status\"><b>Status</b></label>
                    <select id=\"status\" name=\"status\" placeholder=\"Status..\">
                    <option  selected=\"selected\">$status</option>
                    <option  disabled>-------------------------------</option>
                    <option  value=\"Aktivan\">Aktivan</option>
                    <option  value=\"Blokiran\">Blokiran</option>
                    </select>

                    <input name=\"submit\" id=\"submit\" type=\"submit\" value=\"Ažuriraj status korisnika\">";
                    
                            
                    echo "<h2 style=\"text-align:center\"><b>Dodijeli ulogu moderatora</b></h2>";
                    echo "<label for=\"korime\"><b>Korisnik</b></label>
                    <input readonly type=\"text\" value=\"{$_GET['korisnicki_id']}\" name=\"korime\" id=\"korime\">
                        <input readonly type=\"text\" value=\"{$_GET['korisime']}\" name=\"korime1\" id=\"korime1\">
                    

                    <input name=\"submit9\" id=\"submit9\" type=\"submit\" value=\"Dodijeli ulogu moderatora\">";
                }
                ?>

            </form>
            

        </section>
        <br>
        <br>
        <br>
        <br>
    <div class="footer">
        <p>&copy;2020 Lovro Cmrečak</a></p>
    </div>


    </body>
</html>

