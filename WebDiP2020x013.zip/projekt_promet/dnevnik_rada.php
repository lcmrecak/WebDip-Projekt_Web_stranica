<?php

class Dnevnik{
    
    public function unosDnevnik($upit, $radnja, $tip_radnje){
        $veza = new Baza();
        $veza->spojiDB();
        
        if(isset($_SESSION["uloga"])){
            $korisnik= $_SESSION[Sesija::KORISNIK];
        }
        
        if($korisnik==null){
            $korisnik_id=null;
        }else{
            $upitKorisnikId="SELECT korisnik.korisnik_id FROM korisnik WHERE korisnik.korisnicko_ime='{$korisnik}'";
            
            $rezultat = $veza->selectDB($upitKorisnikId);
            $red = mysqli_fetch_array($rezultat);
            $korisnik_id=$red["korisnik_id"];
        }
        
        $trenutnaStranica = $_SERVER['REQUEST_URI'];
        $date=date('Y-m-d H:i:s');
        $coma='"';
        
        $upitInsert= "INSERT INTO `dnevnik` (`dnevnik_id`, `radnja`, `posjecena_stranica`, `datum_vrijeme`, `upit`, `korisnik_korisnik_id`, `tip_radnje_tip_radnje_id`) 
            VALUES (NULL, '{$radnja}', '{$trenutnaStranica}', '{$date}', $coma$upit$coma, '{$korisnik_id}', '{$tip_radnje}');";
        
        $rezultat2 = $veza->selectDB($upitInsert);
        var_dump($rezultat2);
        var_dump($upitInsert);


        
    }
}

