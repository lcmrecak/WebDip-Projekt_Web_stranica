<?php

include 'sesija.class.php';

if(isset($_COOKIE['prijava_sesija'])){
    $korisnik= $_SESSION[Sesija::KORISNIK];
    setcookie("posljednjiUser",$korisnik);
    unset($_COOKIE['prijava_sesija']);
    setcookie('prijava_sesija', null, -1, '/');
    
}

Sesija::obrisiSesiju();
header("Location: obrasci/prijava.php");
exit();