<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$putanja = dirname($_SERVER["REQUEST_URI"]);
$direktorij = dirname(getcwd());
include './zaglavlje.php';
include './dnevnik_rada.php';
$dnevnik = new Dnevnik();


$veza = new Baza();
$veza->spojiDB();

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] <= 2) {
    $korisnik = $_SESSION["korisnik"];
    $upit6 = "SELECT korisnik.korisnik_id FROM korisnik WHERE korisnik.korisnicko_ime = '{$korisnik}'";

    $rezultat6 = $veza->selectDB($upit6);

    $ID_korisnika = 0;
    while ($red1 = mysqli_fetch_array($rezultat6)) {
        $ID_korisnika = $red1[0];
    }

    $upit7 = "SELECT naziv_kategorije, cesta.oznaka, cesta.pocetak_dionice, cesta.zavrsetak_dionice, cesta.broj_kilometara, cesta.status "
            . "FROM kategorija_ceste, ureduje, cesta "
            . "WHERE ureduje.korisnik_korisnik_id='{$ID_korisnika}' "
            . "AND ureduje.kategorija_ceste_kategorija_ceste_id=kategorija_ceste.kategorija_ceste_id "
            . "AND cesta.kategorija_ceste_kategorija_ceste_id=ureduje.kategorija_ceste_kategorija_ceste_id";
    $rezultat7 = $veza->selectDB($upit7);
    $dataRow7 = "";
    while ($red7 = mysqli_fetch_array($rezultat7)) {
        $dataRow7 = $dataRow7 . "<tr><td><a href=\"$putanja/dionice.php?kategorija={$red7['naziv_kategorije']}&oznaka={$red7['oznaka']}&pocetak={$red7['pocetak_dionice']}&kraj={$red7['zavrsetak_dionice']}&km={$red7['broj_kilometara']}&status={$red7['status']}#dodaj\">"
                . "$red7[0]</td><td>$red7[1]</td><td>$red7[2]</td><td>$red7[3]</td><td>$red7[4]</td><td>$red7[5]</td></tr>";
    }


    if (isset($_POST['submit2'])) {
        $kategorija = $_REQUEST['kategorija'];
        var_dump($kategorija);
        $upitID = "SELECT kategorija_ceste.kategorija_ceste_id FROM kategorija_ceste WHERE kategorija_ceste.naziv_kategorije = \"$kategorija\"";
        $rezultat10 = $veza->selectDB($upitID);


        $kategorija_id = 0;
        while ($red10 = mysqli_fetch_array($rezultat10)) {
            $kategorija_id = $red10[0];
        }


        $pocetak = $_REQUEST['pocetak'];
        $kraj = $_REQUEST['kraj'];
        $km = $_REQUEST['km'];
        $oznaka = $_REQUEST['oznaka'];

        $upitInsert = "INSERT INTO `cesta` (`cesta_id`, `oznaka`, `pocetak_dionice`, `zavrsetak_dionice`, `broj_kilometara`, `status`, `kategorija_ceste_kategorija_ceste_id`, `kategorija_ceste_korisnik_korisnik_id`) 
            VALUES (NULL, '{$oznaka}', '{$pocetak}', '{$kraj}', '{$km}', 'O', '{$kategorija_id}', '{$ID_korisnika}');";

        $rezultat8 = $veza->selectDB($upitInsert);


        $dnevnikUpit = $upitInsert;
        $radnja = "Dodana nova dionica";
        $tip_radnje = "2";
        $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);



        header("Location: dionice.php");
    }
    if (isset($_POST['submit1'])) {
        $kategorija = $_REQUEST['kategorija'];
        $upitID = "SELECT kategorija_ceste.kategorija_ceste_id FROM kategorija_ceste WHERE kategorija_ceste.naziv_kategorije = \"$kategorija\"";
        $rezultat10 = $veza->selectDB($upitID);


        $kategorija_id = 0;
        while ($red10 = mysqli_fetch_array($rezultat10)) {
            $kategorija_id = $red10[0];
        }


        $pocetak = $_REQUEST['pocetak'];
        $kraj = $_REQUEST['kraj'];
        $km = $_REQUEST['km'];
        $oznaka = $_REQUEST['oznaka'];
        $status = $_REQUEST['status'];

        $upitUpdate = "UPDATE `cesta` SET `pocetak_dionice` = '{$pocetak}', `zavrsetak_dionice` = '{$kraj}', `broj_kilometara` = '{$km}', `status` = '{$status}', `kategorija_ceste_kategorija_ceste_id` = '{$kategorija_id}',`kategorija_ceste_korisnik_korisnik_id` = '{$ID_korisnika}' 
            WHERE `cesta`.`oznaka` = '{$oznaka}'";

        $rezultat8 = $veza->selectDB($upitUpdate);



        $dnevnikUpit = $upitUpdate;
        $radnja = "Ažurirana dionica ceste";
        $tip_radnje = "2";
        $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);
        header("Location: dionice.php");
    }
}

$upit = "SELECT cesta.oznaka, cesta.pocetak_dionice, cesta.zavrsetak_dionice, kategorija_ceste.naziv_kategorije FROM cesta, kategorija_ceste "
        . "WHERE cesta.kategorija_ceste_kategorija_ceste_id=kategorija_ceste.kategorija_ceste_id "
        . "ORDER BY cesta.kategorija_ceste_kategorija_ceste_id";
$rezultat = $veza->selectDB($upit);
$dataRow = "";
while ($red = mysqli_fetch_array($rezultat)) {
    $dataRow = $dataRow . "<tr><td>$red[0]</td><td>$red[1]</td><td>$red[2]</td><td>$red[3]</td></tr>";
}
$dataRow5 = "";
if (isset($_GET['submit'])) {
    //var_dump($_GET);
    $greska = "";
    $greska2 = "";
    foreach ($_GET as $k => $v) {
        if ($k == 'polaziste') {
            if (empty($v)) {
                $greska .= "Unesite polazište <br>";
            }
        }
        if ($k == 'mail') {
            if (empty($v)) {
                $greska2 .= "Unesite odredište <br>";
            }
        }
    }

    if (empty($greska) && empty($greska2)) {
        $veza = new Baza();
        $veza->spojiDB();

        $polaziste = $_GET['polaziste'];
        $odrediste = $_GET['odrediste'];

        $upit5 = "SELECT oznaka, broj_kilometara FROM cesta "
                . "WHERE cesta.pocetak_dionice = '{$polaziste}' AND cesta.zavrsetak_dionice = '{$odrediste}'";

        $rezultat5 = $veza->selectDB($upit5);
        while ($red5 = mysqli_fetch_array($rezultat5)) {
            $dataRow5 = $dataRow5 . "<tr><td>$red5[0]</td><td>$red5[1]</td></tr>";
        }
    }

    $dnevnikUpit = $upit5;
    $radnja = "Izvršena pretraga dionica";
    $tip_radnje = "3";
    $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);
}
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html lang="hr">
    <head>
        <title>Dionice</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="naslov" content="Promet">        
        <meta name="autor" content="Lovro Cmrecak">
        <meta name="keywords" content="promet, projekt, webdip, dionice">
        <meta name="opis" content="Dionice stranica projekta Promet. Kreirano 2.6.2021.">
        <link href='css/lcmrecak.css' type="text/css" rel="stylesheet"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script>
            $(document).ready(function () {
                $("#myInput").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });

            $(document).ready(function () {
                $("#myInput2").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody2 tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
        </script>

    </head>
    <body>
        <header>
            <img src="multimedija/instagram-logo.png" alt="instagram" width="30"/>
            <img src="multimedija/facebook-logo.png" alt="facebook" width="30"/>
            <a href="rss.php"><img src="multimedija/rss-logo.png" alt="rss" width="30"/></a>
            <a href="#sadrzaj"><h1>PROMET </h1></a>

        </header>
        <nav id="navigacija">
            <?php
            include './meni.php';
            ?>
        </nav>
        <img src="multimedija/road.jpg" alt="cesta" class="responsive" />
        <section id="sadrzaj">
            <h3>Popis dionica</h3>
            <form style="margin-top: 0%">
                <input id="myInput" type="text" placeholder="Pretražite tablicu">
            </form>
            <table>

                <thead>
                    <tr>
                        <th>Oznaka ceste</th>
                        <th>Početak dionice</th>
                        <th>Kraj dionice</th>
                        <th>Kategorija ceste</th>
                    </tr>

                </thead>
                <tbody id="tablicaBody">
                    <?php
                    echo $dataRow;
                    ?>

                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4">PROMET</td>
                    </tr>
                </tfoot>

            </table>
            <h3 style="text-align: center;padding-bottom: 1%">Pretražite ceste</h3>

            <form style="margin-top: 5%; width:20%;display: inline;" action="" name="form" method="get">

                <div class="container2">

                    <label style="margin-left: 22%"for="polaziste"><b>Polazište:</b></label>
                    <input type="text" style="width:15%" placeholder="Unesite mjesto polaska..." name="polaziste" id="polaziste" >

                    <label for="odrediste"><b>Odredište:</b></label>
                    <input type="text" style="width:15%" placeholder="Unesite odredište..." name="odrediste" id="odrediste" >

                    <input name="submit" id="submit" type="submit" value="Pretraži" style="width:15%; margin-left: 0;">

                </div>
            </form>
            <table >

                <thead>
                    <tr>
                        <th>Oznaka ceste</th>
                        <th>Broj kilometara</th>
                    </tr>

                </thead>
                <tbody>
                    <?php
                    echo $dataRow5;
                    ?>

                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3">PROMET</td>
                    </tr>
                </tfoot>

            </table>
            <?php
            if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] <= 2) {
                echo "<h3>Popis dionica kojima upravljate</h3>
                    <form style=\"margin-top: 0%\">
        <input id=\"myInput2\" type=\"text\" placeholder=\"Pretražite tablicu\">
        </form>
                <table>
                    
                    <thead>
                        <tr>
                            <th>Kategorija ceste</th>
                            <th>Oznaka dionice</th>
                            <th>Početak dionice</th>
                            <th>Kraj dionice</th>
                            <th>Broj kilometara</th>
                            <th>Status</th>
                        </tr>

                    </thead>
                    <tbody id=\"tablicaBody2\">
                    
                   
                    $dataRow7
                   

                </tbody>
                <tfoot>
                    <tr>
                        <td colspan=\"6\">PROMET</td>
                    </tr>
                </tfoot>

            </table>";
            }
            ?>
            <form id="form" action="" method="post" style="margin-top: 1%" >

                <div class="container">
                    <h2 style="text-align: center;padding-bottom: 2%;" id="dodaj">Dodaj/ažuriraj dionicu</h2>
                    <?php
                    if (isset($_GET['kategorija'])) {
                        $veza = new Baza();
                        $veza->spojiDB();
                        $selected = $_GET['kategorija'];
                        echo "
                    <label for=\"kategorija\"><b>Kategorija ceste</b></label>
                    <select id=\"kategorija\" name=\"kategorija\" placeholder=\"Kategorija ceste..\">
                    <option  selected=\"selected\">$selected</option>
                    <option  disabled>-------------------------------</option>";

                        $db = "SELECT DISTINCT naziv_kategorije FROM kategorija_ceste, ureduje "
                                . "WHERE ureduje.kategorija_ceste_kategorija_ceste_id=kategorija_ceste.kategorija_ceste_id "
                                . "AND ureduje.korisnik_korisnik_id='{$ID_korisnika}'";
                        $rezultat9 = $veza->selectDB($db);

                        while ($data = mysqli_fetch_array($rezultat9)) {
                            echo "<option name=\"kategorija\" value='{$data["naziv_kategorije"]}'>" . $data['naziv_kategorije'] . "</option>";
                        }
                        echo "</select>";

                        $oznaka = $_GET['oznaka'];
                        $pocetak = $_GET['pocetak'];
                        $kraj = $_GET['kraj'];
                        $km = $_GET['km'];
                        $status = $_GET['status'];
                        echo "<label for=\"oznaka\"><b>Oznaka dionice</b></label>
                    <input type=\"text\" readonly value=\"$oznaka\" placeholder=\"Oznaka ceste...\" name=\"oznaka\" id=\"oznaka\">

                    <label for=\"pocetak\"><b>Početak dionice</b></label>
                    <input type=\"text\" value=\"$pocetak\" placeholder=\"Početak dionice...\" name=\"pocetak\" id=\"pocetak\" >

                    <label for=\"kraj\"><b>Kraj dionice</b></label>
                    <input type=\"text\" value=\"$kraj\" placeholder=\"Kraj dionice...\" name=\"kraj\" id=\"kraj\" >

                    <label for=\"km\"><b>Broj kilometara</b></label>
                    <input type=\"text\" value=\"$km\"  placeholder=\"Broj kilometara...\" name=\"km\" id=\"km\" >
                    
                    <label for=\"status\"><b>Status</b></label>
                    <select id=\"status\" name=\"status\" placeholder=\"Status..\">
                    <option  selected=\"selected\">$status</option>
                    <option  disabled>-------------------------------</option>
                    <option  value=\"O\">O</option>
                    <option  value=\"Z\">Z</option>
                    </select>
                    
                    <input type=\"submit\" value=\"Ažuriraj\" name=\"submit1\" id=\"submit1\">";
                    } else {
                        $veza = new Baza();
                        $veza->spojiDB();
                        echo "
                               
                    <label for=\"kategorija\"><b>Kategorija ceste</b></label>
                    <select id=\"kategorija\" name=\"kategorija\" placeholder=\"Kategorija ceste..\">
                    <option selected></option>";

                        $db = "SELECT DISTINCT naziv_kategorije FROM kategorija_ceste, ureduje "
                                . "WHERE ureduje.kategorija_ceste_kategorija_ceste_id=kategorija_ceste.kategorija_ceste_id "
                                . "AND ureduje.korisnik_korisnik_id='{$ID_korisnika}'";
                        $rezultat9 = $veza->selectDB($db);

                        while ($data = mysqli_fetch_array($rezultat9)) {
                            echo "<option name=\"kategorija\" value='{$data["naziv_kategorije"]}'>" . $data['naziv_kategorije'] . "</option>";
                        }
                        echo "</select>";

                        echo "<label for=\"oznaka\"><b>Oznaka dionice</b></label>
                    <input type=\"text\" placeholder=\"Oznaka ceste...\" name=\"oznaka\" id=\"oznaka\">

                    <label for=\"pocetak\"><b>Početak dionice</b></label>
                    <input type=\"text\" placeholder=\"Početak dionice...\" name=\"pocetak\" id=\"pocetak\" >

                    <label for=\"kraj\"><b>Kraj dionice</b></label>
                    <input type=\"text\" placeholder=\"Kraj dionice...\" name=\"kraj\" id=\"kraj\" >

                    <label for=\"km\"><b>Broj kilometara</b></label>
                    <input type=\"text\" placeholder=\"Broj kilometara...\" name=\"km\" id=\"km\" >
                    <input type=\"submit\" value=\"Dodaj\" name=\"submit2\" id=\"submit2\">";
                    }
                    ?>

                </div>
            </form>

        </section>
<br>
        <br>
        <br>
        <br>
    <div class="footer">
        <p>&copy;2020 Lovro Cmrečak</a></p>
    </div>

    </body>
</html>