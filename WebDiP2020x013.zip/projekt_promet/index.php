<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$putanja = dirname($_SERVER["REQUEST_URI"]);
$direktorij = dirname(getcwd());
include './zaglavlje.php';
include './dnevnik_rada.php';

$veza = new Baza();
$veza->spojiDB();
$dnevnik = new Dnevnik();

$upit = "SELECT COUNT(problem.problem_id) AS 'Broj problema', kategorija_ceste.naziv_kategorije FROM problem "
        . "INNER JOIN cesta ON problem.cesta_id = cesta.cesta_id "
        . "INNER JOIN kategorija_ceste ON cesta.kategorija_ceste_kategorija_ceste_id = kategorija_ceste.kategorija_ceste_id "
        . "GROUP BY kategorija_ceste.kategorija_ceste_id";
$rezultat = $veza->selectDB($upit);
$dataRow = "";
while ($red = mysqli_fetch_array($rezultat)) {
    $dataRow = $dataRow . "<tr><td>$red[0]</td><td>$red[1]</td></tr>";
}

$connect = new PDO("mysql:host=localhost;dbname=WebDiP2020x013", "WebDiP2020x013", "admin_k286");
$get_all_table_query = "SHOW TABLES";
$statement = $connect->prepare($get_all_table_query);
$statement->execute();
$result = $statement->fetchAll();

if (isset($_POST['table'])) {
    $dnevnikUpit = "";
    $radnja = "Kreirana sigurnosna kopija";
    $tip_radnje = "3";
    $upisDnevnik = $dnevnik->unosDnevnik($dnevnikUpit, $radnja, $tip_radnje);


    $output = '';
    foreach ($_POST["table"] as $table) {
        $show_table_query = "SHOW CREATE TABLE " . $table . "";
        $statement = $connect->prepare($show_table_query);
        $statement->execute();
        $show_table_result = $statement->fetchAll();

        foreach ($show_table_result as $show_table_row) {
            $output .= "\n\n" . $show_table_row["Create Table"] . ";\n\n";
        }
        $select_query = "SELECT * FROM " . $table . "";
        $statement = $connect->prepare($select_query);
        $statement->execute();
        $total_row = $statement->rowCount();

        for ($count = 0; $count < $total_row; $count++) {
            $single_result = $statement->fetch(PDO::FETCH_ASSOC);
            $table_column_array = array_keys($single_result);
            $table_value_array = array_values($single_result);
            $output .= "\nINSERT INTO $table (";
            $output .= "" . implode(", ", $table_column_array) . ") VALUES (";
            $output .= "'" . implode("','", $table_value_array) . "');\n";
        }
    }
    $file_name = 'backup/backup.txt';
    $file_handle = fopen($file_name, 'w');
    fwrite($file_handle, $output);
    fclose($file_handle);
    header('Content-Description: File Transfer');
    header('Content-Type: text/plain');
    header('Content-Disposition: attachment; filename=' . basename("backup.txt"));
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize("backup.txt"));
    ob_clean();
    flush();
    readfile($file_name);
    unlink($file_name);
}
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html lang="hr">
    <head>
        <title>Početna</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="naslov" content="Promet">        
        <meta name="autor" content="Lovro Cmrecak">
        <meta name="keywords" content="promet, projekt, webdip">
        <meta name="opis" content="Početna stranica projekta Promet. Kreirano 2.6.2021.">
        <link href='css/lcmrecak.css' type="text/css" rel="stylesheet"/>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="../javascript/lcmrecak_1.js"></script>
        <script>
            $(document).ready(function () {
                $("#myInput").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tablicaBody tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
        </script>



    </head>
    <body>
        <header>
            <img src="multimedija/instagram-logo.png" alt="instagram" width="30"/>
            <img src="multimedija/facebook-logo.png" alt="facebook" width="30"/>
            <a href="rss.php"><img src="multimedija/rss-logo.png" alt="rss" width="30"/></a>
            <script src="../javascript/lcmrecak.js"></script>
    <a id="slika" style="cursor: pointer;" ><img alt="accesibility" src="multimedija/accesibility.png" width="50" /> </a>

            <a href="#sadrzaj"><h1>PROMET </h1></a>

        </header>
        <nav id="navigacija">
<?php
include './meni.php';
?>
        </nav>
        <img src="multimedija/road.jpg" alt="cesta" class="responsive" />
        <section id="sadrzaj">
            <h3>Statistika problema po kategorijama cesta</h3>
            <form style="margin-top: 0%">
                <input id="myInput" type="text" placeholder="Pretražite tablicu">
            </form>
            <table>

                <thead>
                    <tr>
                        <th>Statistika(broj) problema</th>
                        <th>Kategorija ceste</th>
                    </tr>

                </thead>
                <tbody id="tablicaBody">
<?php
echo $dataRow;
?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="2">PROMET</td>
                    </tr>
                </tfoot>

            </table>
<?php
if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] == 1) {

    echo "<form method=\"post\" id=\"export_form\">
     <h3>Napravi sigurnosnu kopiju dionica i dokumenata</h3>";

    foreach ($result as $table) {
        if ($table["Tables_in_WebDiP2020x013"] == "dokument" || $table["Tables_in_WebDiP2020x013"] == "cesta") {
            ?>
                        <div class="checkbox">
                            <label><input type="checkbox" class="checkbox_table" name="table[]" value="<?php echo $table["Tables_in_WebDiP2020x013"]; ?>" checked hidden /></label>
                        </div>
                        <div class="form-group">

                        <?php
                    }
                }
                echo "<input type=\"submit\" name=\"submit\" id=\"submit\" value=\"Kreiraj sigurnosnu kopiju\" />";
            }
            ?>

        </section>
        <br>
        <br>
        <br>
        <br>
    <div class="footer">
        <p>&copy; <a href="autor.html">2020 Lovro Cmrečak</a></p>
        <p>&copy; <a href="dokumenti/dokumentacija.html">Projektna dokumentacija</a></p>
    </div>

    </body>
</html>

<script>
    $(document).ready(function () {
        $('#submit').click(function () {
            var count = 0;
            $('.checkbox_table').each(function () {
                if ($(this).is(':checked'))
                {
                    count = count + 1;
                }
            });
            if (count > 0)
            {
                $('#export_form').submit();
            } else
            {
                alert("Please Select Atleast one table for Export");
                return false;
            }
        });
    });
</script>