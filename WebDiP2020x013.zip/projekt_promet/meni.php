<?php

/*
  + Neregistrirani korisnik može pristupiti stranicama: prijava.php, registracija.php, index.php
  + Registrirani korisnik može pristupiti svemu kao i neregistrirani korisnik plus: popis.php
  + Voditelj može pristupiti svemu kao i registrirani korisnik plus:multimedija.php
  + Administrator može pristupiti svim stranicama.
 */

if(($pageName = basename($_SERVER['PHP_SELF']))=='prijava.php' || ($pageName = basename($_SERVER['PHP_SELF']))=='admin_obrazac.php'||($pageName = basename($_SERVER['PHP_SELF']))=='registracija.php'||($pageName = basename($_SERVER['PHP_SELF']))=='evidencija_problem.php'|| ($pageName = basename($_SERVER['PHP_SELF']))=='dokument_obrazac.php'){
echo "<ul>";
if (!isset($_SESSION["uloga"])) {
    echo "<li><a href=\"$putanja/../obrasci/prijava.php\">Prijava</a></li>";
}
elseif (isset($_SESSION["uloga"])){
    echo "<li><a href=\"$putanja/../odjava.php\">Odjava</a></li>";
}

 echo "<li><a href=\"$putanja/../obrasci/registracija.php\">Registracija</a></li>
        <li><a href=\"$putanja/../dionice.php\">Dionice</a></li>";
if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] < 4) {
    echo "
          <li><a href=\"$putanja/evidencija_problem.php\">Evidentiraj/Prijavi</a></li>
          <li><a href=\"$putanja/dokument_obrazac.php\">Dokumentiraj</a></li>";
}
if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] < 3) {
    
        echo "<li><a href=\"$putanja/../problemi.php\">Problemi</a></li>";  
}
if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] < 2) {
    
        echo "<li><a href=\"$putanja/admin_obrazac.php\">Upravljanje</a></li>"
                . "<li><a href=\"$putanja/../statistika.php\">Statistika</a></li>";  
}
echo "<li><a href=\"$putanja/../index.php\">Početna stranica</a></li>"
        . "</ul>";
}

if(($pageName = basename($_SERVER['PHP_SELF']))=='autor.html'|| ($pageName = basename($_SERVER['PHP_SELF']))=='statistika.php'||($pageName = basename($_SERVER['PHP_SELF']))=='index.php'||($pageName = basename($_SERVER['PHP_SELF']))=='problemi.php'||($pageName = basename($_SERVER['PHP_SELF']))=='dionice.php'){   
 echo "<ul>";
 if (!isset($_SESSION["uloga"])) {
    echo "<li><a href=\"$putanja/obrasci/prijava.php\">Prijava</a></li>";
}
elseif (isset($_SESSION["uloga"])){
    echo "<li><a href=\"$putanja/odjava.php\">Odjava</a></li>";
}
 echo "<li><a href=\"$putanja/obrasci/registracija.php\">Registracija</a></li>
       <li><a href=\"$putanja/dionice.php\">Dionice</a></li>";

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] < 4) {
    echo "
          <li><a href=\"$putanja/obrasci/evidencija_problem.php\">Evidentiraj/Prijavi</a></li>
          <li><a href=\"$putanja/obrasci/dokument_obrazac.php\">Dokumentiraj</a></li>";
}
if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] < 3) {
        
        echo "<li><a href=\"$putanja/problemi.php\">Problemi</a></li>"; 
}
if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] < 2) {
        
        echo "<li><a href=\"$putanja/obrasci/admin_obrazac.php\">Upravljanje</a></li>"
                . "<li><a href=\"$putanja/statistika.php\">Statistika</a></li>"; 
}
echo "<li><a href=\"$putanja/index.php\">Početna stranica</a></li>"
        . "</ul>";
}


