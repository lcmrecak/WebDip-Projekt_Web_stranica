-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 08, 2021 at 08:38 PM
-- Server version: 5.5.62-0+deb8u1
-- PHP Version: 7.2.25-1+0~20191128.32+debian8~1.gbp108445

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `WebDiP2020x013`
--

-- --------------------------------------------------------

--
-- Table structure for table `cesta`
--

CREATE TABLE `cesta` (
  `cesta_id` int(11) NOT NULL,
  `oznaka` varchar(10) NOT NULL,
  `pocetak_dionice` varchar(45) NOT NULL,
  `zavrsetak_dionice` varchar(45) NOT NULL,
  `broj_kilometara` float NOT NULL,
  `status` char(1) NOT NULL,
  `kategorija_ceste_kategorija_ceste_id` int(11) NOT NULL,
  `kategorija_ceste_korisnik_korisnik_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cesta`
--

INSERT INTO `cesta` (`cesta_id`, `oznaka`, `pocetak_dionice`, `zavrsetak_dionice`, `broj_kilometara`, `status`, `kategorija_ceste_kategorija_ceste_id`, `kategorija_ceste_korisnik_korisnik_id`) VALUES
(1, 'A1', 'Zagreb', 'Dubrovnik', 550, 'O', 1, 1),
(2, 'A5', 'Beli Manastir', 'Đakovo', 77, 'Z', 1, 2),
(3, 'D89', 'Gornji Macelj', 'Split', 600, 'O', 2, 2),
(4, 'D65', 'Varaždin', 'Ilok', 390, 'Z', 2, 2),
(5, 'E56', 'Rijeka', 'Pula', 80, 'Z', 2, 2),
(6, 'DC4', 'Poreč', 'Rovinj', 45, 'Z', 3, 2),
(7, 'A6', 'Bosiljevo', 'Rijeka', 81, 'O', 1, 3),
(8, '20023', 'Čakovec', 'Pribislavec', 2, 'Z', 4, 3),
(9, '20028', 'Čakovec', 'Pribislavec', 3, 'O', 4, 1),
(10, '20382', 'Gornji Kneginec', 'Vidovec', 16, 'Z', 3, 2),
(27, '30083', 'Varaždin', 'Ivanec', 40, 'Z', 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `dnevnik`
--

CREATE TABLE `dnevnik` (
  `dnevnik_id` int(11) NOT NULL,
  `radnja` varchar(500) NOT NULL,
  `posjecena_stranica` varchar(255) NOT NULL,
  `datum_vrijeme` datetime NOT NULL,
  `upit` varchar(500) NOT NULL,
  `korisnik_korisnik_id` int(11) NOT NULL,
  `tip_radnje_tip_radnje_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dnevnik`
--

INSERT INTO `dnevnik` (`dnevnik_id`, `radnja`, `posjecena_stranica`, `datum_vrijeme`, `upit`, `korisnik_korisnik_id`, `tip_radnje_tip_radnje_id`) VALUES
(34, 'Kreirana sigurnosna kopija', '/lcmrecak/projekt_promet/index.php', '2021-06-07 00:05:47', '', 1, 3),
(36, 'Kreirana nova kategorija ceste', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php', '2021-06-07 00:15:53', 'INSERT INTO `kategorija_ceste` (`kategorija_ceste_id`, `naziv_kategorije`, `opis_kategorije`) VALUES (NULL, \'proba \', \'proba\');', 1, 2),
(37, 'Kreirana nova kategorija ceste', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php', '2021-06-07 00:16:26', 'INSERT INTO `kategorija_ceste` (`kategorija_ceste_id`, `naziv_kategorije`, `opis_kategorije`) VALUES (NULL, \'proba \', \'proba\');', 1, 2),
(38, 'Ažurirana kategorija ceste', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php?kategorija_id=10&kategorija=Makadam&opis=%C5%A0ljun%C4%8Dana%20cesta%20ili%20put.', '2021-06-07 00:18:09', 'UPDATE `kategorija_ceste` SET `naziv_kategorije` = \'Makadam\', `opis_kategorije` = \'Šljunčana cesta \' WHERE `kategorija_ceste`.`kategorija_ceste_id` = 10;', 1, 2),
(39, 'Obrisana kategorija ceste', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php?kategorija_id=10&kategorija=Makadam&opis=%C5%A0ljun%C4%8Dana%20cesta', '2021-06-07 00:18:45', 'DELETE FROM `kategorija_ceste` WHERE `kategorija_ceste`.`kategorija_ceste_id` = 10', 1, 2),
(40, 'Dodijeljena uloga moderatora registriranom korisniku', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php?korisnicki_id=22&korime=aanic', '2021-06-07 00:20:00', 'UPDATE `korisnik` SET `uloga_korisnika_uloga_korisnika_id` = \'2\' WHERE `korisnik`.`korisnik_id` = 22;', 1, 2),
(41, 'Dodijeljena kategorija ceste moderatoru', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php?moderator_id=22&modime=aanic', '2021-06-07 00:21:34', 'INSERT INTO `ureduje` (`korisnik_korisnik_id`, `kategorija_ceste_kategorija_ceste_id`) VALUES (\'22\', \'4\');', 1, 2),
(42, 'Prenesena datoteka i upisana u bazu', '/lcmrecak/projekt_promet/obrasci/dokument_obrazac.php', '2021-06-07 00:24:12', 'INSERT INTO `dokument` (`dokument_id`, `naziv_dokumenta`, `vrsta_dokumenta`, `status`, `vrijeme_prijenosa`, `cesta_cesta_id`, `korisnik_korisnik_id`) \n                VALUES (NULL, \'photo3.jpg\', \'image/jpeg\', \'N\', \'2021-06-07 00:24:12\', \'5\', \'1\');\n', 1, 2),
(49, 'Dodijeljena kategorija ceste moderatoru', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php?moderator_id=21&modime=iivic', '2021-06-07 00:50:15', 'INSERT INTO `ureduje` (`korisnik_korisnik_id`, `kategorija_ceste_kategorija_ceste_id`) VALUES (\'21\', \'1\');', 1, 2),
(50, 'Dodijeljena kategorija ceste moderatoru', '/lcmrecak/projekt_promet/dionice.php?kategorija=Autocesta&oznaka=A3&pocetak=Karlovac&kraj=Plo%C4%8De&km=400&status=O', '2021-06-07 01:05:21', 'UPDATE `cesta` SET `pocetak_dionice` = \'Karlovac\', `zavrsetak_dionice` = \'Ploče\', `broj_kilometara` = \'500\', `status` = \'O\', `kategorija_ceste_kategorija_ceste_id` = \'1\',`kategorija_ceste_korisnik_korisnik_id` = \'1\' WHERE `cesta`.`oznaka` = \'A3\'', 1, 2),
(51, 'Kreirana sigurnosna kopija', '/lcmrecak/projekt_promet/index.php', '2021-06-07 01:07:56', '', 1, 3),
(54, 'Ažurirana dionica ceste', '/lcmrecak/projekt_promet/dionice.php?kategorija=Autocesta&oznaka=A3&pocetak=Kurceva%20pripizdina&kraj=Plo%C4%8De&km=600&status=O', '2021-06-07 01:14:23', 'UPDATE `cesta` SET `pocetak_dionice` = \'Kurceva pripizdina\', `zavrsetak_dionice` = \'Ploče\', `broj_kilometara` = \'12\', `status` = \'O\', `kategorija_ceste_kategorija_ceste_id` = \'1\',`kategorija_ceste_korisnik_korisnik_id` = \'1\' \n            WHERE `cesta`.`oznaka` = \'A3\'', 1, 2),
(55, 'Izvršena pretraga dionica', '/lcmrecak/projekt_promet/dionice.php?polaziste=Zagreb&odrediste=Dubrovnik&submit=Pretra%C5%BEi', '2021-06-07 01:16:07', 'SELECT oznaka, broj_kilometara FROM cesta WHERE cesta.pocetak_dionice = \'Zagreb\' AND cesta.zavrsetak_dionice = \'Dubrovnik\'', 1, 3),
(56, 'Izvršena pretraga dionica', '/lcmrecak/projekt_promet/dionice.php?polaziste=Zagreb&odrediste=Dubrovnik&submit=Pretra%C5%BEi', '2021-06-07 01:17:08', 'SELECT oznaka, broj_kilometara FROM cesta WHERE cesta.pocetak_dionice = \'Zagreb\' AND cesta.zavrsetak_dionice = \'Dubrovnik\'', 1, 3),
(57, 'Izvršena pretraga dionica', '/lcmrecak/projekt_promet/dionice.php?polaziste=Zagreb&odrediste=Dubrovnik&submit=Pretra%C5%BEi', '2021-06-07 01:18:40', 'SELECT oznaka, broj_kilometara FROM cesta WHERE cesta.pocetak_dionice = \'Zagreb\' AND cesta.zavrsetak_dionice = \'Dubrovnik\'', 1, 3),
(58, 'Ažuriran status ceste', '/lcmrecak/projekt_promet/problemi.php?oznaka=D65&status=O', '2021-06-07 01:19:05', 'UPDATE `cesta` SET `status` = \'Z\' WHERE `cesta`.`cesta_id` = 4', 1, 2),
(59, 'Uspješna prijava', '/lcmrecak/projekt_promet/obrasci/prijava.php?korime=lcmrecak&lozinka=admin_001&submit=Prijavi+se', '2021-06-07 01:25:34', '', 1, 1),
(60, 'Uspješna prijava', '/lcmrecak/projekt_promet/obrasci/prijava.php?korime=mmaric&lozinka=lozinka1&submit=Prijavi+se', '2021-06-07 01:26:18', '', 2, 1),
(61, 'Kreirana sigurnosna kopija', '/lcmrecak/projekt_promet/index.php', '2021-06-07 02:24:32', '', 1, 3),
(62, 'Kreirana sigurnosna kopija', '/lcmrecak/projekt_promet/index.php', '2021-06-07 02:25:51', '', 1, 3),
(63, 'Kreirana sigurnosna kopija', '/lcmrecak/projekt_promet/index.php', '2021-06-07 02:26:28', '', 1, 3),
(64, 'Uspješna prijava', '/lcmrecak/projekt_promet/obrasci/prijava.php?korime=lcmrecak&lozinka=admin_001&submit=Prijavi+se', '2021-06-07 02:41:12', '', 1, 1),
(65, 'Uspješna prijava', '/lcmrecak/projekt_promet/obrasci/prijava.php?korime=lcmrecak&lozinka=admin_001&submit=Prijavi+se', '2021-06-07 02:41:25', '', 1, 1),
(66, 'Uspješna prijava', '/lcmrecak/projekt_promet/obrasci/prijava.php?korime=lcmrecak&lozinka=admin_001&submit=Prijavi+se', '2021-06-07 02:49:23', '', 1, 1),
(67, 'Kreirana nova kategorija ceste', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php', '2021-06-07 03:01:56', 'INSERT INTO `kategorija_ceste` (`kategorija_ceste_id`, `naziv_kategorije`, `opis_kategorije`) VALUES (NULL, \'\', \'\');', 1, 2),
(68, 'Kreirana nova kategorija ceste', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php', '2021-06-07 03:01:58', 'INSERT INTO `kategorija_ceste` (`kategorija_ceste_id`, `naziv_kategorije`, `opis_kategorije`) VALUES (NULL, \'\', \'\');', 1, 2),
(69, 'Kreirana nova kategorija ceste', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php', '2021-06-07 03:02:50', 'INSERT INTO `kategorija_ceste` (`kategorija_ceste_id`, `naziv_kategorije`, `opis_kategorije`) VALUES (NULL, \'\', \'\');', 1, 2),
(70, 'Kreirana nova kategorija ceste', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php', '2021-06-07 03:03:28', 'INSERT INTO `kategorija_ceste` (`kategorija_ceste_id`, `naziv_kategorije`, `opis_kategorije`) VALUES (NULL, \'\', \'\');', 1, 2),
(71, 'Kreirana nova kategorija ceste', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php', '2021-06-07 03:08:48', 'INSERT INTO `kategorija_ceste` (`kategorija_ceste_id`, `naziv_kategorije`, `opis_kategorije`) VALUES (NULL, \'proba\', \'proba\');', 1, 2),
(72, 'Ažurirana kategorija ceste', '/lcmrecak/projekt_promet/obrasci/admin_obrazac.php?kategorija_id=22&kategorija=&opis=', '2021-06-07 03:10:32', 'UPDATE `kategorija_ceste` SET `naziv_kategorije` = \'aa\', `opis_kategorije` = \'a\' WHERE `kategorija_ceste`.`kategorija_ceste_id` = 22;', 1, 2),
(185, 'Kreirana sigurnosna kopija', '/lcmrecak/projekt_promet/index.php', '2021-06-07 17:32:22', '', 1, 3),
(186, 'Uspješna prijava', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/prijava.php?korime=lcmrecak&lozinka=admin_001&submit=Prijavi+se', '2021-06-07 22:12:01', '', 1, 1),
(187, 'Kreirana sigurnosna kopija', '/WebDiP/2020_projekti/WebDiP2020x013/index.php', '2021-06-07 22:12:11', '', 1, 3),
(188, 'Obrisana kategorija ceste', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/admin_obrazac.php?kategorija_id=23&kategorija=proba&opis=proba', '2021-06-07 22:12:30', 'DELETE FROM `kategorija_ceste` WHERE `kategorija_ceste`.`kategorija_ceste_id` = 23', 1, 2),
(189, 'Obrisana kategorija ceste', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/admin_obrazac.php?kategorija_id=22&kategorija=aa&opis=a', '2021-06-07 22:12:45', 'DELETE FROM `kategorija_ceste` WHERE `kategorija_ceste`.`kategorija_ceste_id` = 22', 1, 2),
(190, 'Obrisana kategorija ceste', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/admin_obrazac.php?kategorija_id=21&kategorija=&opis=', '2021-06-07 22:12:48', 'DELETE FROM `kategorija_ceste` WHERE `kategorija_ceste`.`kategorija_ceste_id` = 21', 1, 2),
(191, 'Obrisana kategorija ceste', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/admin_obrazac.php?kategorija_id=20&kategorija=&opis=', '2021-06-07 22:12:50', 'DELETE FROM `kategorija_ceste` WHERE `kategorija_ceste`.`kategorija_ceste_id` = 20', 1, 2),
(192, 'Obrisana kategorija ceste', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/admin_obrazac.php?kategorija_id=19&kategorija=&opis=', '2021-06-07 22:12:53', 'DELETE FROM `kategorija_ceste` WHERE `kategorija_ceste`.`kategorija_ceste_id` = 19', 1, 2),
(193, 'Prenesena datoteka i upisana u bazu', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/dokument_obrazac.php', '2021-06-07 22:16:26', 'INSERT INTO `dokument` (`dokument_id`, `naziv_dokumenta`, `vrsta_dokumenta`, `status`, `vrijeme_prijenosa`, `cesta_cesta_id`, `korisnik_korisnik_id`) \n                VALUES (NULL, \'primjer27_1.php\', \'application/x-php\', \'N\', \'2021-06-07 22:16:26\', \'1\', \'1\');\n', 1, 2),
(194, 'Kreirana sigurnosna kopija', '/WebDiP/2020_projekti/WebDiP2020x013/index.php', '2021-06-07 22:18:11', '', 1, 3),
(195, 'Ažurirana dionica ceste', '/WebDiP/2020_projekti/WebDiP2020x013/dionice.php?kategorija=Lokalna%20cesta&oznaka=20028&pocetak=%C4%8Cakovec&kraj=Pribislavec&km=3&status=O', '2021-06-07 22:25:18', 'UPDATE `cesta` SET `pocetak_dionice` = \'Čakovec\', `zavrsetak_dionice` = \'Pribislavec\', `broj_kilometara` = \'3\', `status` = \'Z\', `kategorija_ceste_kategorija_ceste_id` = \'4\',`kategorija_ceste_korisnik_korisnik_id` = \'1\' \n            WHERE `cesta`.`oznaka` = \'20028\'', 1, 2),
(196, 'Ažuriran status ceste', '/WebDiP/2020_projekti/WebDiP2020x013/problemi.php?oznaka=20028&status=Z', '2021-06-08 01:33:58', 'UPDATE `cesta` SET `status` = \'O\' WHERE `cesta`.`cesta_id` = 9', 2, 2),
(197, 'Prenesena datoteka i upisana u bazu', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/dokument_obrazac.php', '2021-06-08 01:35:32', 'INSERT INTO `dokument` (`dokument_id`, `naziv_dokumenta`, `vrsta_dokumenta`, `status`, `vrijeme_prijenosa`, `cesta_cesta_id`, `korisnik_korisnik_id`) \n                VALUES (NULL, \'primjer27_1.php\', \'application/x-php\', \'N\', \'2021-06-08 01:35:32\', \'1\', \'2\');\n', 2, 2),
(198, 'Kreirana sigurnosna kopija', '/WebDiP/2020_projekti/WebDiP2020x013/index.php', '2021-06-08 16:05:28', '', 1, 3),
(199, 'Kreirana sigurnosna kopija', '/WebDiP/2020_projekti/WebDiP2020x013/index.php', '2021-06-08 16:06:02', '', 1, 3),
(200, 'Kreirana sigurnosna kopija', '/WebDiP/2020_projekti/WebDiP2020x013/index.php', '2021-06-08 16:11:45', '', 1, 3),
(201, 'Promijenjen status korisnika', '/WebDiP/2020_projekti/WebDiP2020x013/forbidden/korisnici.php?korisnicki_id=33&status=Aktivan', '2021-06-08 16:52:26', 'UPDATE `korisnik` SET `status` = \'Blokiran\' WHERE `korisnik`.`korisnik_id` = {\'33\'};', 1, 2),
(202, 'Promijenjen status korisnika', '/WebDiP/2020_projekti/WebDiP2020x013/forbidden/korisnici.php?korisnicki_id=33&status=Aktivan', '2021-06-08 16:53:13', 'UPDATE `korisnik` SET `status` = \'Blokiran\' WHERE `korisnik`.`korisnik_id` = {\'33\'};', 1, 2),
(203, 'Promijenjen status korisnika', '/WebDiP/2020_projekti/WebDiP2020x013/forbidden/korisnici.php?korisnicki_id=33&status=Aktivan', '2021-06-08 16:54:58', 'UPDATE `korisnik` SET `status` = \'Aktivan\' WHERE `korisnik`.`korisnik_id` = \'33\';', 1, 2),
(204, 'Promijenjen status korisnika', '/WebDiP/2020_projekti/WebDiP2020x013/forbidden/korisnici.php?korisnicki_id=30&status=Aktivan', '2021-06-08 16:57:00', 'UPDATE `korisnik` SET `status` = \'Blokiran\' WHERE `korisnik`.`korisnik_id` = \'30\';', 1, 2),
(205, 'Uspješna prijava', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/prijava.php?korime=lcmrecak&lozinka=admin_001&submit=Prijavi+se', '2021-06-08 17:00:10', '', 1, 1),
(206, 'Uspješna prijava', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/prijava.php?korime=lcmrecak&lozinka=admin_001&submit=Prijavi+se', '2021-06-08 17:08:25', '', 1, 1),
(207, 'Uspješna prijava', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/prijava.php?korime=lcmrecak&lozinka=admin_001&submit=Prijavi+se', '2021-06-08 17:26:53', '', 1, 1),
(208, 'Promijenjen status korisnika', '/WebDiP/2020_projekti/WebDiP2020x013/forbidden/korisnici.php?korisnicki_id=34&status=Blokiran', '2021-06-08 17:28:40', 'UPDATE `korisnik` SET `status` = \'Aktivan\' WHERE `korisnik`.`korisnik_id` = \'34\';', 1, 2),
(209, 'Uspješna prijava', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/prijava.php?korime=lcmrecak&lozinka=admin_001&submit=Prijavi+se', '2021-06-08 17:39:45', '', 1, 1),
(210, 'Dodijeljena uloga moderatora registriranom korisniku', '/WebDiP/2020_projekti/WebDiP2020x013/forbidden/korisnici.php?korisnicki_id=38&status=Aktivan&korisime=dlovren', '2021-06-08 17:40:04', 'UPDATE `korisnik` SET `uloga_korisnika_uloga_korisnika_id` = \'2\' WHERE `korisnik`.`korisnik_id` = 38;', 1, 2),
(211, 'Dodijeljena kategorija ceste moderatoru', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/admin_obrazac.php?moderator_id=38&modime=dlovren', '2021-06-08 17:41:02', 'INSERT INTO `ureduje` (`korisnik_korisnik_id`, `kategorija_ceste_kategorija_ceste_id`) VALUES (\'38\', \'4\');', 1, 2),
(212, 'Uspješna prijava', '/WebDiP/2020_projekti/WebDiP2020x013/obrasci/prijava.php?korime=lcmrecak&lozinka=admin_001&submit=Prijavi+se', '2021-06-08 19:43:05', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dokument`
--

CREATE TABLE `dokument` (
  `dokument_id` int(11) NOT NULL,
  `naziv_dokumenta` varchar(50) NOT NULL,
  `vrsta_dokumenta` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `vrijeme_prijenosa` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cesta_cesta_id` int(11) NOT NULL,
  `korisnik_korisnik_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dokument`
--

INSERT INTO `dokument` (`dokument_id`, `naziv_dokumenta`, `vrsta_dokumenta`, `status`, `vrijeme_prijenosa`, `cesta_cesta_id`, `korisnik_korisnik_id`) VALUES
(1, 'a1.jpg', 'Slika', 'P', '2021-06-04 21:01:13', 1, 14),
(2, 'primjer27_1.php', 'application/x-php', 'P', '2021-06-04 21:21:09', 1, 14),
(3, 'primjer27_1.php', 'application/x-php', 'N', '2021-06-04 21:27:31', 1, 14),
(6, 'WebDiP2020x013.sql', 'application/sql', 'O', '2021-06-05 18:55:42', 3, 2),
(7, 'photo3.jpg', 'image/jpeg', 'N', '2021-06-05 18:57:21', 5, 2),
(8, 'marvel-studios-logo.png', 'image/png', 'O', '2021-06-05 18:58:39', 1, 2),
(10, 'photo3.jpg', 'image/jpeg', 'N', '2021-06-06 22:24:12', 5, 1),
(11, 'photo6.jpg', 'image/jpeg', 'N', '2021-06-07 01:18:15', 5, 1),
(12, 'dokumentidatabase_backup_on_21-06-07.sql', 'application/sql', 'N', '2021-06-07 01:20:14', 5, 1),
(13, 'primjer27_1.php', 'application/x-php', 'N', '2021-06-07 20:14:11', 1, 1),
(14, 'primjer27_1.php', 'application/x-php', 'N', '2021-06-07 20:16:26', 1, 1),
(15, 'primjer27_1.php', 'application/x-php', 'N', '2021-06-07 23:34:32', 1, 2),
(16, 'primjer27_1.php', 'application/x-php', 'N', '2021-06-07 23:35:32', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `DZ4_korisnik`
--

CREATE TABLE `DZ4_korisnik` (
  `korisnik_id` int(11) NOT NULL,
  `ime` varchar(45) NOT NULL,
  `prezime` varchar(45) NOT NULL,
  `korisnicko_ime` varchar(45) NOT NULL,
  `lozinka` varchar(25) NOT NULL,
  `lozinka_sha256` char(64) NOT NULL,
  `email` varchar(45) NOT NULL,
  `DZ4_uloga_korisnika_uloga_korisnika_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `DZ4_korisnik`
--

INSERT INTO `DZ4_korisnik` (`korisnik_id`, `ime`, `prezime`, `korisnicko_ime`, `lozinka`, `lozinka_sha256`, `email`, `DZ4_uloga_korisnika_uloga_korisnika_id`) VALUES
(1, 'Lovro', 'Cmrečak', 'lcmrecak', 'admin_001', 'eac2a33b110637750cd2067be1753924618d0fc3', 'lcmrecak@foi.hr', 1),
(2, 'Marko', 'Marić', 'mmaric', 'lozinka1', 'aaf6cc744d2471fc3bf7293388e93998459f610f', 'mmaric@foi.hr', 2),
(3, 'Pero', 'Peric', 'pperic', 'lozinka2', '6c08ef7d6e6b75f701dd2924f9c85fab635e81f4', 'pperic@foi.hr', 3),
(4, 'Maja', 'Majic', 'mmajic', 'lozinka3', 'b0af1b7a5bd9047dc779175da8c6ef8ee02268b6', 'mmajic@foi.hr', 3),
(5, 'Ana', 'Anic', 'aanic', 'lozinka4', '463c349f6411df5251abaad392cb85f3506ebbc4', 'aanic@foi.hr', 3),
(6, 'Toni', 'Tonic', 'ttoonic', 'lozinka5', '6e40988bc310adcab2100147a53d45be491ad425', 'ttonic@foi.hr', 3),
(7, 'Antonio', 'Cmrecak', 'acmrecak', '12345', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', 'acmrecak@foi.hr', 3),
(25, 'Proba', 'Probic', 'proba1', 'proba1proba', '8e92e56f58fecbd9a55a687ccf7cfdd94e714a47adb35ba1f179b3b1c63e8143', 'proba@gmail.com', 3);

-- --------------------------------------------------------

--
-- Table structure for table `DZ4_obrazac`
--

CREATE TABLE `DZ4_obrazac` (
  `lik_id` int(11) NOT NULL,
  `ime_lika` varchar(45) NOT NULL,
  `glumac` varchar(45) NOT NULL,
  `boja_odijela` varchar(45) NOT NULL,
  `izlazak_prvog_filma` varchar(45) NOT NULL,
  `vrijeme_unosa` varchar(45) NOT NULL,
  `broj_filmova` int(11) NOT NULL,
  `faze_pojavljivanja` varchar(50) NOT NULL,
  `broj_cameo_uloga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `DZ4_obrazac`
--

INSERT INTO `DZ4_obrazac` (`lik_id`, `ime_lika`, `glumac`, `boja_odijela`, `izlazak_prvog_filma`, `vrijeme_unosa`, `broj_filmova`, `faze_pojavljivanja`, `broj_cameo_uloga`) VALUES
(24, 'Iron Man', 'Robert Downey Jr.', '#e65c00', '04.04.2008.', '11:12:35 AM', 1, 'Faza 1', 4),
(29, 'Captain Marvel', 'Brie Larson', '#4fbf6b', '12.02.2019.', '11:12:35 AM', 2, 'Faza 3', 1),
(30, 'Hulk', 'Mark Ruffalo,Edward Norton', '#52922f', '12.08.2008.', '11:12:35 AM', 5, 'Faza 1', 1),
(31, 'Spider-Man', 'Jeremy Renner,Tom Holland', '#d11515', '12.07.2017.', '11:12:35 AM', 6, 'Faza 3', 1),
(34, 'Black Panther', 'Chris Evans,Mark Ruffalo', '#000000', '12.12.1999.', '11:12:35 AM', 2, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `DZ4_uloga_korisnika`
--

CREATE TABLE `DZ4_uloga_korisnika` (
  `uloga_korisnika_id` int(11) NOT NULL,
  `naziv` varchar(45) NOT NULL,
  `opis_uloge` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `DZ4_uloga_korisnika`
--

INSERT INTO `DZ4_uloga_korisnika` (`uloga_korisnika_id`, `naziv`, `opis_uloge`) VALUES
(1, 'Administrator', 'Administrator ima najveće ovlasti.'),
(2, 'Moderator', 'Moderatora dodjeljuje administrator'),
(3, 'Registrirani korisnik', 'Korisnik s aktiviranom registracijom.'),
(4, 'Neregistrirani korisnik', 'Korisnik s osnovnim funkcionalnostima.');

-- --------------------------------------------------------

--
-- Table structure for table `kategorija_ceste`
--

CREATE TABLE `kategorija_ceste` (
  `kategorija_ceste_id` int(11) NOT NULL,
  `naziv_kategorije` varchar(45) NOT NULL,
  `opis_kategorije` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kategorija_ceste`
--

INSERT INTO `kategorija_ceste` (`kategorija_ceste_id`, `naziv_kategorije`, `opis_kategorije`) VALUES
(1, 'Autocesta', 'Cesta isključivo za prometovanje motornih vozila s dvije odvojene kolničke trake, svaka za jedan smjer.'),
(2, 'Državna cesta', 'Javna cesta koja povezuje cjelokupno državno područje.'),
(3, 'Županijska cesta', 'Javna cesta koja povezuje cjelokupno županijsko područje.'),
(4, 'Lokalna cesta', 'Javna cesta na lokalnom području.');

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `korisnik_id` int(11) NOT NULL,
  `ime` varchar(45) NOT NULL,
  `prezime` varchar(45) NOT NULL,
  `korisnicko_ime` varchar(45) NOT NULL,
  `lozinka` varchar(25) NOT NULL,
  `lozinka_sha56` char(64) NOT NULL,
  `email` varchar(45) NOT NULL,
  `status` enum('Aktivan','Blokiran') NOT NULL,
  `datum_registracije` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `broj_neuspjesnih_prijava` int(11) NOT NULL,
  `uvjeti_koristenja` varchar(30) NOT NULL,
  `uloga_korisnika_uloga_korisnika_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`korisnik_id`, `ime`, `prezime`, `korisnicko_ime`, `lozinka`, `lozinka_sha56`, `email`, `status`, `datum_registracije`, `broj_neuspjesnih_prijava`, `uvjeti_koristenja`, `uloga_korisnika_uloga_korisnika_id`) VALUES
(1, 'Lovro', 'Cmrečak', 'lcmrecak', 'admin_001', 'eac2a33b110637750cd2067be1753924618d0fc3', 'lcmrecak@foi.hr', 'Aktivan', '2021-06-02 23:00:41', 0, '', 1),
(2, 'Marko', 'Marić', 'mmaric', 'lozinka1', 'aaf6cc744d2471fc3bf7293388e93998459f610f', 'mmaric@foi.hr', 'Aktivan', '2021-06-15 23:00:52', 0, '', 2),
(14, 'Luka', 'Lukic', 'llukic', '12345', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', 'llukic@gmail.com', 'Aktivan', '2021-06-03 15:10:42', 0, 'prihvaceni', 3),
(21, 'Ivo', 'Ivic', 'iivic', 'lozinka3', '65b287cf4f1fd0a04cea95cb1a59c8a95743a33c9259c5f59290ff207f5f33e0', 'iivic@gmail.com', 'Aktivan', '2021-05-31 23:07:45', 0, 'prihvaceni', 2),
(22, 'Ana', 'Anic', 'aanic', 'lozinka4', 'c12b5c292ed51227f6a05bd821da1f35f31865e3b02c4241dd390d24ca79f5cd', 'aanic@gmail.com', 'Aktivan', '2021-06-06 23:07:45', 0, 'prihvaceni', 2),
(34, 'Jura ', 'Jurić', 'jjuric1', 'Lozinka6', '06712bfe83a352b97be55c94136ac908f3b71acb7994d81760ba20a1084991fd', 'jjuric@gmail.com', 'Aktivan', '2021-06-08 15:28:40', 0, 'prihvaceni', 3),
(35, 'Antonio', 'Marić', 'amaric', 'Lozinka6', '06712bfe83a352b97be55c94136ac908f3b71acb7994d81760ba20a1084991fd', 'amaric@gmail.com', 'Aktivan', '2021-06-08 15:20:22', 0, 'prihvaceni', 3),
(36, 'Iva', 'Andić', 'iandric', 'Lozinka7', '61a29ad9bdef4c797238d00d31b294df38c6f3f2379567ce87e4bef8bfd53796', 'iandric@foi.hr', 'Aktivan', '2021-06-08 15:20:54', 0, 'prihvaceni', 3),
(37, 'Lorena', 'Modrić', 'lmodric', 'Lozinka10', '61248cde783f3cbc0229ae91ef468f39022e491436aa3f34f28794d5ff2abcb5', 'lmodric@gmail.com', 'Aktivan', '2021-06-08 15:21:41', 0, 'prihvaceni', 3),
(38, 'Dejan', 'Lovren', 'dlovren', 'Lozinka14', '99be87589e45b730979469e46b26bdff277bba9a97900149de4af93618bc0161', 'dlovren@gmail.com', 'Aktivan', '2021-06-08 15:40:04', 0, 'prihvaceni', 2),
(39, 'Danica', 'Suput', 'dsuput', 'Lozinka69', 'bbf3546212a3f6c6233c8f44a8db51dc5ae1a24891d3f2a8ab112af04568ea82', 'dsuput@gmail.com', 'Aktivan', '2021-06-08 15:26:32', 0, 'prihvaceni', 3);

-- --------------------------------------------------------

--
-- Table structure for table `obilazak`
--

CREATE TABLE `obilazak` (
  `obilazak_id` int(11) NOT NULL,
  `cesta_cesta_id` int(11) NOT NULL,
  `korisnik_korisnik_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `obilazak`
--

INSERT INTO `obilazak` (`obilazak_id`, `cesta_cesta_id`, `korisnik_korisnik_id`) VALUES
(1, 1, 1),
(2, 2, 14),
(4, 3, 14),
(5, 6, 1),
(6, 9, 1),
(7, 8, 1),
(8, 8, 1),
(18, 1, 14),
(20, 4, 14),
(21, 6, 14),
(23, 7, 14),
(24, 3, 1),
(42, 9, 1),
(43, 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `obilazi`
--

CREATE TABLE `obilazi` (
  `korisnik_korisnik_id` int(11) NOT NULL,
  `cesta_cesta_id` int(11) NOT NULL,
  `cesta_kategorija_ceste_kategorija_ceste_id` int(11) NOT NULL,
  `cesta_kategorija_ceste_korisnik_korisnik_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `obilazi`
--

INSERT INTO `obilazi` (`korisnik_korisnik_id`, `cesta_cesta_id`, `cesta_kategorija_ceste_kategorija_ceste_id`, `cesta_kategorija_ceste_korisnik_korisnik_id`) VALUES
(1, 1, 1, 1),
(2, 2, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `prijava`
--

CREATE TABLE `prijava` (
  `prijava_id` int(11) NOT NULL,
  `naziv` varchar(45) NOT NULL,
  `datum` datetime NOT NULL,
  `vrijeme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `korisnik_korisnik_id` int(11) NOT NULL,
  `cesta_cesta_id` int(11) NOT NULL,
  `cesta_kategorija_ceste_kategorija_ceste_id` int(11) NOT NULL,
  `cesta_kategorija_ceste_korisnik_korisnik_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prijava`
--

INSERT INTO `prijava` (`prijava_id`, `naziv`, `datum`, `vrijeme`, `korisnik_korisnik_id`, `cesta_cesta_id`, `cesta_kategorija_ceste_kategorija_ceste_id`, `cesta_kategorija_ceste_korisnik_korisnik_id`) VALUES
(4, 'Prijava1', '2021-04-21 09:21:23', '2021-06-07 20:10:21', 1, 1, 1, 1),
(5, 'Prijava2', '2021-04-11 06:26:00', '2021-06-07 20:10:21', 2, 2, 1, 2),
(6, 'Prijava3', '2021-04-16 00:00:00', '2021-06-07 20:10:21', 2, 3, 2, 2),
(7, 'Prijava4', '2021-04-24 00:25:33', '2021-06-07 20:10:21', 2, 4, 2, 2),
(9, 'Prijava5', '2021-04-29 14:30:00', '2021-06-07 20:10:21', 2, 5, 2, 2),
(10, 'Prijava6', '2021-04-29 16:00:40', '2021-06-07 20:10:21', 2, 6, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `problem`
--

CREATE TABLE `problem` (
  `problem_id` int(11) NOT NULL,
  `naziv_problema` varchar(30) NOT NULL,
  `opis` varchar(50) NOT NULL,
  `datum_vrijeme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cesta_id` int(11) NOT NULL,
  `korisnik_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `problem`
--

INSERT INTO `problem` (`problem_id`, `naziv_problema`, `opis`, `datum_vrijeme`, `cesta_id`, `korisnik_id`) VALUES
(1, 'Sudar', 'Sudar dvaju ili više vozila na cesti.', '2021-06-03 18:38:35', 1, 3),
(2, 'Gužva', 'Gužva na cesti.', '2021-06-03 18:38:35', 3, 2),
(3, 'Nesreća', 'Nesreća s ozlijeđenim osobama.', '2021-06-03 23:33:49', 2, 3),
(4, 'Nevrijeme', 'Olujno nevrijeme na cesti.', '2021-06-03 23:33:49', 5, 3),
(5, 'Skliski kolnik', 'Skliski kolnik, teško upravljanje vozilom.', '2021-06-03 23:35:40', 6, 3),
(6, 'Grabe na cesti', 'Cesta je puna graba', '2021-06-04 17:09:54', 4, 14),
(7, 'Oštećenje kolnika', 'Na kolniku je sve puno pukotina i oštećenja.', '2021-06-04 17:14:30', 9, 14),
(12, 'asdsa', 'sdfds', '2021-06-04 17:45:20', 8, 14),
(13, '', '', '2021-06-07 01:24:15', 0, 1),
(14, '', '', '2021-06-07 01:24:16', 0, 1),
(15, '', '', '2021-06-07 01:24:17', 0, 1),
(16, '', '', '2021-06-07 01:24:18', 0, 1),
(17, '', '', '2021-06-07 01:24:21', 0, 1),
(18, 'n', 'j', '2021-06-07 02:18:02', 3, 27),
(19, '', '', '2021-06-07 14:06:51', 0, 1),
(20, '', '', '2021-06-07 14:06:56', 0, 1),
(21, '', '', '2021-06-07 14:07:01', 3, 1),
(22, 'Oštećenje kolnika', 'df', '2021-06-07 14:07:13', 9, 1),
(23, 'dfsdfsd', 'ds', '2021-06-07 14:10:09', 7, 1),
(24, 'dfd', 'erer', '2021-06-07 14:10:47', 9, 1),
(25, 'df', 'sdf', '2021-06-07 14:23:45', 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sigurnosna_kopija`
--

CREATE TABLE `sigurnosna_kopija` (
  `sigurnosna_kopija_id` int(11) NOT NULL,
  `naziv` varchar(45) NOT NULL,
  `vrijeme_kreiranja` datetime NOT NULL,
  `korisnik_korisnik_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sigurnosna_kopija`
--

INSERT INTO `sigurnosna_kopija` (`sigurnosna_kopija_id`, `naziv`, `vrijeme_kreiranja`, `korisnik_korisnik_id`) VALUES
(1, 'SigurnosnaKopija1', '2021-04-08 11:33:33', 1),
(2, 'SIgurnosnaKopija2', '2021-04-23 17:45:46', 1),
(3, 'SigurnosnaKopija3', '2021-04-27 06:29:31', 1),
(4, 'SigurnosnaKopija4', '2021-04-30 00:00:00', 1),
(5, 'SigurnosnaKopija5', '2021-05-19 13:00:00', 1),
(6, 'SigurnosnaKopija6', '2021-05-18 06:27:36', 1);

-- --------------------------------------------------------

--
-- Table structure for table `testna`
--

CREATE TABLE `testna` (
  `testna` int(11) NOT NULL,
  `kita` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `testna`
--

INSERT INTO `testna` (`testna`, `kita`) VALUES
(1, 1),
(2, 22);

-- --------------------------------------------------------

--
-- Table structure for table `tip_radnje`
--

CREATE TABLE `tip_radnje` (
  `tip_radnje_id` int(11) NOT NULL,
  `naziv` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tip_radnje`
--

INSERT INTO `tip_radnje` (`tip_radnje_id`, `naziv`) VALUES
(1, 'prijava/odjava'),
(2, 'rad s bazom'),
(3, 'ostalo');

-- --------------------------------------------------------

--
-- Table structure for table `uloga_korisnika`
--

CREATE TABLE `uloga_korisnika` (
  `uloga_korisnika_id` int(11) NOT NULL,
  `naziv` varchar(45) NOT NULL,
  `opis_uloge` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uloga_korisnika`
--

INSERT INTO `uloga_korisnika` (`uloga_korisnika_id`, `naziv`, `opis_uloge`) VALUES
(1, 'Administrator', 'Administrator ima najveće ovlasti.'),
(2, 'Moderator', 'Moderatora dodjeljuje administrator'),
(3, 'Registrirani korisnik', 'Korisnik s aktiviranom registracijom.'),
(4, 'Neregistrirani korisnik', 'Korisnik s osnovnim funkcionalnostima.');

-- --------------------------------------------------------

--
-- Table structure for table `ureduje`
--

CREATE TABLE `ureduje` (
  `korisnik_korisnik_id` int(11) NOT NULL,
  `kategorija_ceste_kategorija_ceste_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ureduje`
--

INSERT INTO `ureduje` (`korisnik_korisnik_id`, `kategorija_ceste_kategorija_ceste_id`) VALUES
(1, 1),
(21, 1),
(2, 2),
(21, 2),
(2, 3),
(22, 3),
(1, 4),
(2, 4),
(21, 4),
(22, 4),
(38, 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cesta`
--
ALTER TABLE `cesta`
  ADD PRIMARY KEY (`cesta_id`,`kategorija_ceste_kategorija_ceste_id`,`kategorija_ceste_korisnik_korisnik_id`),
  ADD KEY `fk_cesta_kategorija_ceste1_idx` (`kategorija_ceste_kategorija_ceste_id`,`kategorija_ceste_korisnik_korisnik_id`);

--
-- Indexes for table `dnevnik`
--
ALTER TABLE `dnevnik`
  ADD PRIMARY KEY (`dnevnik_id`,`korisnik_korisnik_id`,`tip_radnje_tip_radnje_id`),
  ADD KEY `fk_dnevnik_korisnik1_idx` (`korisnik_korisnik_id`),
  ADD KEY `fk_dnevnik_tip_radnje1_idx` (`tip_radnje_tip_radnje_id`);

--
-- Indexes for table `dokument`
--
ALTER TABLE `dokument`
  ADD PRIMARY KEY (`dokument_id`),
  ADD KEY `fk_dokument_cesta2_idx` (`cesta_cesta_id`),
  ADD KEY `fk_dokument_korisnik2_idx` (`korisnik_korisnik_id`);

--
-- Indexes for table `DZ4_korisnik`
--
ALTER TABLE `DZ4_korisnik`
  ADD PRIMARY KEY (`korisnik_id`),
  ADD KEY `fk_DZ4_korisnik_uloga_korisnika_idx` (`DZ4_uloga_korisnika_uloga_korisnika_id`);

--
-- Indexes for table `DZ4_obrazac`
--
ALTER TABLE `DZ4_obrazac`
  ADD PRIMARY KEY (`lik_id`);

--
-- Indexes for table `DZ4_uloga_korisnika`
--
ALTER TABLE `DZ4_uloga_korisnika`
  ADD PRIMARY KEY (`uloga_korisnika_id`);

--
-- Indexes for table `kategorija_ceste`
--
ALTER TABLE `kategorija_ceste`
  ADD PRIMARY KEY (`kategorija_ceste_id`);

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`korisnik_id`),
  ADD KEY `fk_korisnik_uloga_korisnika_idx` (`uloga_korisnika_uloga_korisnika_id`);

--
-- Indexes for table `obilazak`
--
ALTER TABLE `obilazak`
  ADD PRIMARY KEY (`obilazak_id`),
  ADD KEY `fk_user_cesta1_idx` (`cesta_cesta_id`),
  ADD KEY `fk_obilazak_korisnik1_idx` (`korisnik_korisnik_id`);

--
-- Indexes for table `obilazi`
--
ALTER TABLE `obilazi`
  ADD PRIMARY KEY (`korisnik_korisnik_id`,`cesta_cesta_id`,`cesta_kategorija_ceste_kategorija_ceste_id`,`cesta_kategorija_ceste_korisnik_korisnik_id`),
  ADD KEY `fk_korisnik_has_cesta_korisnik1_idx` (`korisnik_korisnik_id`),
  ADD KEY `fk_upravlja_cesta1_idx` (`cesta_cesta_id`,`cesta_kategorija_ceste_kategorija_ceste_id`,`cesta_kategorija_ceste_korisnik_korisnik_id`);

--
-- Indexes for table `prijava`
--
ALTER TABLE `prijava`
  ADD PRIMARY KEY (`prijava_id`,`korisnik_korisnik_id`,`cesta_cesta_id`,`cesta_kategorija_ceste_kategorija_ceste_id`,`cesta_kategorija_ceste_korisnik_korisnik_id`),
  ADD KEY `fk_prijava_korisnik1_idx` (`korisnik_korisnik_id`),
  ADD KEY `fk_prijava_cesta1_idx` (`cesta_cesta_id`,`cesta_kategorija_ceste_kategorija_ceste_id`,`cesta_kategorija_ceste_korisnik_korisnik_id`);

--
-- Indexes for table `problem`
--
ALTER TABLE `problem`
  ADD PRIMARY KEY (`problem_id`),
  ADD KEY `cesta_id` (`cesta_id`),
  ADD KEY `korisnik_id` (`korisnik_id`);

--
-- Indexes for table `sigurnosna_kopija`
--
ALTER TABLE `sigurnosna_kopija`
  ADD PRIMARY KEY (`sigurnosna_kopija_id`,`korisnik_korisnik_id`),
  ADD KEY `fk_sigurnosna_kopija_korisnik1_idx` (`korisnik_korisnik_id`);

--
-- Indexes for table `testna`
--
ALTER TABLE `testna`
  ADD PRIMARY KEY (`testna`);

--
-- Indexes for table `tip_radnje`
--
ALTER TABLE `tip_radnje`
  ADD PRIMARY KEY (`tip_radnje_id`);

--
-- Indexes for table `uloga_korisnika`
--
ALTER TABLE `uloga_korisnika`
  ADD PRIMARY KEY (`uloga_korisnika_id`);

--
-- Indexes for table `ureduje`
--
ALTER TABLE `ureduje`
  ADD PRIMARY KEY (`korisnik_korisnik_id`,`kategorija_ceste_kategorija_ceste_id`),
  ADD KEY `fk_korisnik_has_kategorija_ceste_kategorija_ceste1_idx` (`kategorija_ceste_kategorija_ceste_id`),
  ADD KEY `fk_korisnik_has_kategorija_ceste_korisnik1_idx` (`korisnik_korisnik_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cesta`
--
ALTER TABLE `cesta`
  MODIFY `cesta_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `dnevnik`
--
ALTER TABLE `dnevnik`
  MODIFY `dnevnik_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=213;
--
-- AUTO_INCREMENT for table `dokument`
--
ALTER TABLE `dokument`
  MODIFY `dokument_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `DZ4_korisnik`
--
ALTER TABLE `DZ4_korisnik`
  MODIFY `korisnik_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `DZ4_obrazac`
--
ALTER TABLE `DZ4_obrazac`
  MODIFY `lik_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `DZ4_uloga_korisnika`
--
ALTER TABLE `DZ4_uloga_korisnika`
  MODIFY `uloga_korisnika_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `kategorija_ceste`
--
ALTER TABLE `kategorija_ceste`
  MODIFY `kategorija_ceste_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `korisnik_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `obilazak`
--
ALTER TABLE `obilazak`
  MODIFY `obilazak_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `prijava`
--
ALTER TABLE `prijava`
  MODIFY `prijava_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `problem`
--
ALTER TABLE `problem`
  MODIFY `problem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `sigurnosna_kopija`
--
ALTER TABLE `sigurnosna_kopija`
  MODIFY `sigurnosna_kopija_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `testna`
--
ALTER TABLE `testna`
  MODIFY `testna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tip_radnje`
--
ALTER TABLE `tip_radnje`
  MODIFY `tip_radnje_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `uloga_korisnika`
--
ALTER TABLE `uloga_korisnika`
  MODIFY `uloga_korisnika_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cesta`
--
ALTER TABLE `cesta`
  ADD CONSTRAINT `fk_cesta_kategorija_ceste1` FOREIGN KEY (`kategorija_ceste_kategorija_ceste_id`) REFERENCES `kategorija_ceste` (`kategorija_ceste_id`);

--
-- Constraints for table `dnevnik`
--
ALTER TABLE `dnevnik`
  ADD CONSTRAINT `fk_dnevnik_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_dnevnik_tip_radnje1` FOREIGN KEY (`tip_radnje_tip_radnje_id`) REFERENCES `tip_radnje` (`tip_radnje_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dokument`
--
ALTER TABLE `dokument`
  ADD CONSTRAINT `fk_dokument_cesta2` FOREIGN KEY (`cesta_cesta_id`) REFERENCES `cesta` (`cesta_id`),
  ADD CONSTRAINT `fk_dokument_korisnik2` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`);

--
-- Constraints for table `DZ4_korisnik`
--
ALTER TABLE `DZ4_korisnik`
  ADD CONSTRAINT `fk_DZ4_korisnik_uloga_korisnika` FOREIGN KEY (`DZ4_uloga_korisnika_uloga_korisnika_id`) REFERENCES `DZ4_uloga_korisnika` (`uloga_korisnika_id`);

--
-- Constraints for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD CONSTRAINT `fk_korisnik_uloga_korisnika` FOREIGN KEY (`uloga_korisnika_uloga_korisnika_id`) REFERENCES `uloga_korisnika` (`uloga_korisnika_id`);

--
-- Constraints for table `obilazak`
--
ALTER TABLE `obilazak`
  ADD CONSTRAINT `fk_obilazak_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_cesta1` FOREIGN KEY (`cesta_cesta_id`) REFERENCES `cesta` (`cesta_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `obilazi`
--
ALTER TABLE `obilazi`
  ADD CONSTRAINT `fk_korisnik_has_cesta_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_upravlja_cesta1` FOREIGN KEY (`cesta_cesta_id`,`cesta_kategorija_ceste_kategorija_ceste_id`,`cesta_kategorija_ceste_korisnik_korisnik_id`) REFERENCES `cesta` (`cesta_id`, `kategorija_ceste_kategorija_ceste_id`, `kategorija_ceste_korisnik_korisnik_id`);

--
-- Constraints for table `prijava`
--
ALTER TABLE `prijava`
  ADD CONSTRAINT `fk_prijava_cesta1` FOREIGN KEY (`cesta_cesta_id`,`cesta_kategorija_ceste_kategorija_ceste_id`,`cesta_kategorija_ceste_korisnik_korisnik_id`) REFERENCES `cesta` (`cesta_id`, `kategorija_ceste_kategorija_ceste_id`, `kategorija_ceste_korisnik_korisnik_id`),
  ADD CONSTRAINT `fk_prijava_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`);

--
-- Constraints for table `sigurnosna_kopija`
--
ALTER TABLE `sigurnosna_kopija`
  ADD CONSTRAINT `fk_sigurnosna_kopija_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ureduje`
--
ALTER TABLE `ureduje`
  ADD CONSTRAINT `fk_korisnik_has_kategorija_ceste_kategorija_ceste1` FOREIGN KEY (`kategorija_ceste_kategorija_ceste_id`) REFERENCES `kategorija_ceste` (`kategorija_ceste_id`),
  ADD CONSTRAINT `fk_korisnik_has_kategorija_ceste_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
